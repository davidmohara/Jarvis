# Changelog

All notable changes to IES (Improving Executive System). Versions were established retroactively on 2026-10-08 from git history (1,063 commits since 2026-02-05) to give the system a formal release record. Tags mark stable points; dated entries summarize the dominant work of each era with representative commits.

## [Unreleased] — 2026-10 systemization (started 2026-10-08)

- Remediation plan tracked locally: `projects/remediation-plan.md` (9 findings, all mapped to phases).
- Workflow rationalization memo (`projects/workflow-rationalization-memo-2026-10-08.md`): candidate set rationalized to boot, morning-briefing, daily-review, plaud-ingest; weekly-review dropped.
- Coordinator purity refactor (in flight) (spawn-first enforcement, no direct git/shell/domain execution by the coordinator).
- Per-step audit trail (in flight) in the eval harness (per-step model, input tokens, output tokens, cost) with CSV/JSON export.
- Per-agent evaluation artifacts for all 11 agents (draft set retired; agent definitions live in `agents/`).
- CHANGELOG established, retroactive version tags created.
- Eval-harness exit reliability (2026-10-10): SessionEnd hook re-engineered to spawn the canonical closer (`close-open-evals.py`) detached, so a standard exit can no longer cancel the sweep mid-run and leave eval records open; regression suite `test_eval_session_end.py` (40bc6ef4). Protects the success-rate data window from open-record distortion.
- YAML hygiene (2026-10-10): colon-bearing values quoted in `plaud-ingest-verification` frontmatter and boot `state.yaml` after both became unparseable (turn-start frontmatter errors, `boot_is_fresh` fallback); quoting rule added to agent conventions so agent-written YAML cannot reintroduce the defect.
- Git gate command-position coverage (2026-10-10): both gate layers anchored git detection to position zero, so `cd "<repo>" && git <write-verb>` reached raw git unaudited (found in production via the git-ops spool, bypass evidence `systems/eval-harness/bypass-tests/BT-06-git-cmdpos-bypass-2026-10-10.md`); detection now matches git at any command position with quotes stripped, compound writes block, compound reads pass, 13 new regression cases including end-to-end through `pre-tool-use.sh`.
- Planned: v2.0.0 tagged at the next resubmission.

## [v1.5.0] — 2026-09-16: access consolidation and deterministic grading

- OmniFocus access consolidated onto two skills (`omnifocus-data`, `omnifocus-tasks`) with the osascript fallback path verified end-to-end (6aeb691d, eb6eec1f).
- Deterministic Tier 2 grading on every skill invocation (3068d935) and per-turn token breakdown in daily-cost-check (5f7c283e).
- Reusable skills: schema-validator, delivery-router (c6da964c); calendar-handler, visual-verification (eda9d815).
- Golf skills converted to workflows with quality gates (628983a4).

## [v1.0.0] — 2026-08-22: delegation system build

- Guardrail checkpoints with real audit trail and sentinel files across workflows (a3acd571); Boot system complete and production ready (4ee4e3a6).
- Eval-hook lifecycle rebuilt with intelligent retry behavior for guardrail checkpoints (2393b9a0, e9887470).
- Ground-truth verifier scripts and workflow-specific verifier dispatcher across 13 workflows (a562eaeb, 53bc7d23); guardrail output-field contracts documented in boot step frontmatter (ce9b61d0).
- Podcast-to-Pipeline campaign system (aedc13de); token efficiency optimizations, 8 consolidation improvements (2220912a).

## [v0.5.0] — 2026-06-19: system hardening and standing intelligence

- Git operations skill established as the only authorized path for all git operations (03967217).
- Two-tier skill architecture, stubs, model pins, SessionStart hook, release watch audit (55452fdb).
- Watchtower standing intelligence workflow (b853978f); both-sides political news monitor (a9876a8b).
- Routing hard stops with lazy-loaded routing.md and pre-action hook (a55b68b4, 2026-05-04).
- Session continuity index system (6866ea1d, 2026-05-08); automated content generation from Slack to Ghost (94745b6c).

## [v0.1.0] — 2026-02-05: initial system

- Initial commit: Executive Operating System (50cbe123); Jarvis identity, context, and boot sequence (6f61209c).
- OmniFocus integration with person-tag conventions (2110e68b, db0f5a59).
- Agent roster grew through spring: Sterling (2026-03-27), Galen with WHOOP integration (2026-04-01), tiered memory with dream cycle and skill manifest (2026-04-18).

---

Tag map (annotated tags on the listed commits): v0.1.0 → 50cbe123 · v0.5.0 → 55452fdb · v1.0.0 → 4ee4e3a6 · v1.5.0 → 6aeb691d · v2.0.0 → planned at next resubmission.
