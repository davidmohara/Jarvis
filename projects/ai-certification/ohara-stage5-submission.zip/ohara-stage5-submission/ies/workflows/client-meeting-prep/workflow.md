---
name: client-meeting-prep
description: Client/prospect meeting prep - email-first reason-for-call verification, attendee and company research, calibrated talking points, landmines
agent: chase
model: sonnet
---

<!-- system:start -->
# Client Meeting Prep Workflow

**Goal:** Walk into every external call knowing *why the meeting actually exists* — not why it looks like it exists. Web research and calendar metadata are supplements, never substitutes, for what the connected email account already knows about the relationship. No surprises. No invented sales narrative. No wrong titles.

**Agent:** Chase — Revenue, Pipeline & Client Strategy

**Architecture:** Sequential 5-step workflow.

1. **Identify the meeting** — logistics, attendees, verified local time.
2. **Establish ground truth from email** — query the connected email/calendar tool for the actual introduction or most recent thread with the attendee(s) BEFORE any web research. Classify the meeting type from that evidence.
3. **Research the company and attendee** — disambiguate company identity first, then build out company and bio context, calibrated to the classification from step 2.
4. **Build the prep sheet** — assemble the final deliverable in the canonical format. Pre-call only — no post-call action items.
5. **Generate PDF and deliver to reMarkable** — render the prep sheet to PDF and push it to David's tablet via Knox, using the hardened reMarkable delivery protocol.
6. **Adversarial verification**: Ralph cross-checks the prep sheet against source data (every attendee/company fact traced to calendar, email, or CRM; no invented attendees) and records the `adversarial-verification` checkpoint.

No user interaction required until the prep sheet is delivered, except where a step's Failure Modes require surfacing an unresolved gap.
<!-- system:end -->

<!-- personal:start -->
<!-- personal:end -->

---

<!-- system:start -->
## INITIALIZATION

### Required Input

- **Who**: Name of the external attendee(s) and/or their company
- **When**: Date and time of the meeting (if known, otherwise find it on calendar)

### Data Sources Required

| Source | What to Pull | Access Method | Priority |
|--------|-------------|----------------|----------|
| Email/Calendar connector | Meeting logistics, attendees, AND the introduction/most-recent thread with the attendee(s) | Connected email/calendar MCP tool per SYSTEM.md connector resolution (e.g., `mcp__1f6e0bda-36e0-456c-956f-abc8f14b8b8c__query_email_and_calendar` / `get_thread`, or M365 MCP `outlook_calendar_search` when authorized) | **First — mandatory, run before web research** |
| Local system clock | Ground truth for the Mac's actual local time and timezone | `osascript` `date` command via Desktop Commander or Control_your_Mac | First — before stating any meeting time |
| CRM | Prior opportunity/account history if the company already exists as a client | CRM via Chrome/M365 auth, if a connector is active | Second |
| Web | Company profile, attendee bio, LinkedIn, recent news | Web search | Second — supplements, never substitutes for email evidence |
| Knowledge layer | Past meeting notes, relationship history, prior prep docs for this person/company | Knowledge base API / Obsidian | Second |

### Output

- Prep sheet saved to knowledge layer / working directory: `{Person Name} — {Company} — {YYYY-MM-DD}.md`
- Clean markdown starting directly with the H1 title — **no YAML frontmatter block** in the deliverable itself (the workflow's own step files carry frontmatter; the output document does not).
- **No "Next Steps" or post-call action item section.** This is a pre-call prep sheet. It does not presume outcomes.
<!-- system:end -->

<!-- personal:start -->
<!-- personal:end -->

---

<!-- system:start -->
## STATE CHECK

Read and follow `reference/state-check-protocol.md` before any execution. Workflow: `client-meeting-prep`; agent: `chase`.

## EXECUTION

Read fully and follow, in order:

1. `steps/step-01-identify-meeting.md`
2. `steps/step-02-source-of-truth-email.md`
3. `steps/step-03-research-company-and-attendee.md`
4. `steps/step-04-build-prep-sheet.md`
5. `steps/step-05-remarkable-delivery.md`
6. `steps/step-06-adversarial-verify.md`: terminal adversarial verification. Spawns **Ralph** with `workflows/client-meeting-prep-verification/workflow.md` (the prep-sheet-claims-vs-source-data lens). Ralph traces every attendee and company fact in the sheet back to a calendar, email, or CRM record and returns a verdict table; the result is recorded as an `adversarial-verification` guardrail checkpoint. The workflow is marked complete only at the end of this step.

Each step file names the next step at its end. Do not skip ahead — step 2's classification output gates the tone and content of steps 3 and 4. Step-05 records a `pre-delivery-review` guardrail checkpoint before the tablet upload; step-06 records the `adversarial-verification` checkpoint.

**Deterministic step guardrails:** Every step transition is machine-checked. The verifiers in `workflows/client-meeting-prep/verify/` run at each step's completion (dispatched by `.claude/hooks/step-complete.py`) and record a pass/retry/fail verdict with derived fields on the run's eval record.
<!-- system:end -->

<!-- personal:start -->
<!-- personal:end -->
