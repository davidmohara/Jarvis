---
purpose: Staging area for source proposals awaiting David's yes/no approval
gate: David must explicitly approve before any source moves to sources.yaml
updated: 2026-09-14
---

<!-- system:start -->
# Watchtower — Proposed Sources

This file is the only path to `sources.yaml`. Watchtower's weekly run appends new proposals here. David reviews, says yes or no per row, and Rigby moves approved entries to `sources.yaml`.

**Nothing in this file is active.** Active sources live in `sources.yaml` only.

---

## Approval Queue

<!-- Weekly run appends proposals below this line. Format:
| Name | URL | RSS | Topic | Trust | Why Relevant | Status |
|------|-----|-----|-------|-------|--------------|--------|
-->

### Batch 12 — Weekly Run (2026-09-07)

| Name | URL | RSS | Topic | Trust | Why Relevant | Status |
|------|-----|-----|-------|-------|--------------|--------|
| HBR — AI & Leadership | https://hbr.org/topic/subject/ai-and-machine-learning | null | leadership | high | Published "The AI Leadership Imperative" (Apr 2026), "What AI Can't Do: The New Job of Leadership" (Apr 2026), and multiple AI management pieces directly tied to W37's manager-as-multiplier theme. Practitioner-level leadership analysis with high editorial bar. No dedicated RSS for AI/leadership subcategory; gather_method: search via site:hbr.org. | approved 2026-09-08 |
| Retool Blog | https://retool.com/blog | https://retool.com/blog/rss.xml | it-consulting | high | Published the 2026 Build vs. Buy Report (Feb 2026) — 817 respondents, 35% have already replaced SaaS with custom builds, 78% expect to build more in 2026. Directly sourced W37's build-decision theme with practitioner-level methodology data. No comparable primary-research source on enterprise software procurement shift in current registry. RSS feed unverified — confirm on first run. | rejected 2026-09-08 |
| CIO (IDG) | https://www.cio.com | https://www.cio.com/feed/ | it-consulting | high | Published "The SaaS reckoning: Why AI is about to reprice enterprise software" directly tied to W37's build-decision theme. CIO is the primary trade publication for enterprise IT leadership — covers procurement decisions, delivery model shifts, and AI adoption at the CIO level. Fills a gap between Gartner (analyst) and Stratechery (strategic) with practitioner-decision-maker focus. RSS feed unverified — confirm on first run. | rejected 2026-09-08 |
| People Results (Gallup analysis) | https://peopleresults.com | null | leadership | med | Published synthesis of Gallup State of the Global Workplace 2026 including the manager-as-AI-multiplier finding (8.7x adoption rate). Practitioner-focused HR and leadership advisory. Covers the organizational change management layer that W37 Theme 2 centers on. No RSS confirmed; gather_method: search via site:peopleresults.com. | approved 2026-09-08 |
| Security Boulevard | https://securityboulevard.com | https://securityboulevard.com/feed/ | ai-agentic | high | Published "9 Enterprise Identity Trends That Will Define 2026" directly sourcing W37's agent identity incident theme. Aggregates practitioner security research from CISOs and enterprise security teams. Fills a gap between CyberArk (vendor) and OWASP (standards) with independent editorial coverage of enterprise identity and agent security. RSS feed unverified — confirm on first run. | rejected 2026-09-08 |

### Batch 11 — Weekly Run (2026-08-31)

| Name | URL | RSS | Topic | Trust | Why Relevant | Status |
|------|-----|-----|-------|-------|--------------|--------|
| The AI Optimist | https://www.aioptimist.org | https://www.aioptimist.org/feed (unverified) | leadership | med | Weekly newsletter on AI strategy for leaders — pragmatic adoption framing, change management, and team upskilling. Directly relevant to David's leadership/human-side-of-AI lenses. No comparable leader-focused adoption strategy publication in current registry beyond CEOWORLD. Free tier available. | approved 2026-08-31 |
| AI Leadership Weekly | https://aileadershipweekly.com | null | leadership | med | C-suite-structured weekly newsletter on turning AI awareness into organizational action. Published strategic frameworks for AI adoption decisions — directly tied to W36's theme on project viability and governance gaps. No RSS confirmed; gather_method: search. | rejected 2026-08-31 |
| The Crossing Report | https://crossing.one | https://crossing.one/feed (unverified) | it-consulting | high | Published "Consulting Firm Pricing: The AI-Era Shift" directly sourcing W36's billing model theme — outcome-based pricing transition, McKinsey Acorn Plan framing, client value squeeze. Practitioner-level consulting business intelligence. No comparable pricing/business-model-focused source in current registry. | rejected 2026-08-31 |
| Chief Reinvention Officer | https://chiefreinventionofficer.com/blog-page | null | it-consulting | med | Published "9 Trends Reshaping the Consulting Industry in 2026" covering outcome-based pricing, AI agent delivery, and the consulting business model inflection. Practitioner-adjacent thought leadership on firm-level strategy. No RSS confirmed; gather_method: search via site:chiefreinventionofficer.com. | rejected 2026-08-31 |
| Consultancy.uk | https://www.consultancy.uk | https://www.consultancy.uk/feed (unverified) | it-consulting | high | Published "What it takes to make outcome-based pricing work in consulting" (Aug 2026). UK-headquartered but covers global consulting industry — M&A, pricing models, delivery restructuring, and AI consulting trends. High editorial bar, consistent publication cadence. Fills a consulting-industry-news gap between Stratechery (strategic) and Gartner (analyst). | rejected 2026-08-31 |

### Batch 10 — Weekly Run (2026-08-24)

| Name | URL | RSS | Topic | Trust | Why Relevant | Status |
|------|-----|-----|-------|-------|--------------|--------|
| CEOWORLD Magazine | https://ceoworld.biz | https://ceoworld.biz/feed | leadership | med | Published "Designing organizations differently — shaping the workplace to unlock potential in an AI-enhanced world" (Aug 2, 2026) directly tied to W35's org design / human-centered AI theme. Covers AI leadership, org design, and CEO-level transformation at a practitioner-accessible level. No comparable leadership-focused publication in current registry beyond EOS Worldwide Blog. | approved 2026-08-24 |
| Josh Bersin | https://joshbersin.com | https://joshbersin.com/feed | leadership | high | Primary independent analyst on AI, HR, workforce transformation, and learning. Published "The Superworker Organization" (2026 HR Imperatives) and "How AI Transforms $400B of Corporate Learning." Directly relevant to W35's skill atrophy / expertise erosion theme and the human side of AI transformation. High editorial bar, practitioner-trusted, no vendor affiliation. | rejected 2026-08-24 |
| Prosci Blog | https://www.prosci.com/blog | null | leadership | high | Published "Why AI Transformation Fails" (Jun 2026) and 2026 State of AI Adoption study (1,107 professionals, user proficiency as primary failure mode at 38%). Primary practitioner source on change management for AI adoption — directly sourced W35 Theme 1 data on leadership trust gap and adoption failure modes. No RSS confirmed; gather_method: search via site:prosci.com/blog. | approved 2026-08-24 |
| DDI (Development Dimensions International) | https://www.ddi.com/blog | https://www.ddi.com/blog/rss | leadership | high | Published "Leadership Trends 2026" covering AI leadership capability, the trust gap between frontline workers and executives, and the 3.15-point leadership support spread as the primary adoption predictor. Primary data source for W35 Theme 1. Covers leadership research at the rigor level of a consulting firm but publishes free. RSS URL unverified — confirm on first run. | rejected 2026-08-24 |
| Dallas Innovates (AI 75 / Vertical AI coverage) | https://dallasinnovates.com | https://dallasinnovates.com/feed | texas-regional | high | Already active in registry for DFW innovation coverage — but W35 surfaced the 2026 AI 75 innovators list and Brookings AI Star Hub coverage as distinct, higher-signal content than the feed currently surfaces. NOTE: If the main dallasinnovates.com feed is already active, this row should be skipped — only add if a separate AI-scoped feed exists. Flagging for David's awareness rather than as a new source addition. | already active — no action needed |

### Batch 9 — Weekly Run (2026-08-20)

| Name | URL | RSS | Topic | Trust | Why Relevant | Status |
|------|-----|-----|-------|-------|--------------|--------|
| The EU AI Act Newsletter | https://artificialintelligenceact.substack.com | https://artificialintelligenceact.substack.com/feed | ai-agentic | high | Biweekly newsletter by the Future of Life Institute tracking EU AI Act enforcement, compliance developments, and regulatory interpretations. Published issue #108 on "Enforcement Begins" covering the Aug 2 high-risk AI deadline. The EU AI Act compliance gap is now an active near-term consulting revenue story for US enterprises with EU operations. No regulatory-tracking source currently in registry. | rejected 2026-08-24 |
| Texas Impact | https://texasimpact.substack.com | https://texasimpact.substack.com/feed | texas-regional | med | Municipal-level Texas infrastructure and policy advocacy newsletter. Published "Data Center Deluge" covering city council opposition to data center development. Fills the city-level Texas policy gap that Texas Tribune covers only at the state level. Directly relevant to this week's San Marcos ban and Austin-area municipal resistance story. | rejected 2026-08-24 |
| Responsible AI Labs | https://responsibleailabs.ai | https://responsibleailabs.ai/feed | ai-agentic | high | Published the EU AI Act August 2026 compliance countdown and maintains a knowledge hub on AI governance frameworks. Practitioner-focused, not vendor-affiliated. Covers the intersection of regulatory compliance and enterprise AI deployment at a level of specificity no current registry source matches for governance-adjacent consulting. RSS feed unverified -- confirm on first run. | rejected 2026-08-24 |

### Batch 8 — Weekly Run (2026-08-17)

| Name | URL | RSS | Topic | Trust | Why Relevant | Status |
|------|-----|-----|-------|-------|--------------|--------|
| Data Center Frontier | https://www.datacenterfrontier.com | https://www.datacenterfrontier.com/feed/ | texas-regional | high | Primary trade publication for data center infrastructure, power policy, and AI data center development. Directly covered the Texas oversight tightening story (Aug 2026) and the Abbott grid connection moratorium. Fills a gap between Texas Tribune (general news) and Gartner (analyst) with infrastructure-specific depth for Texas AI build-out coverage. | rejected |
| TechScoop (Substack) | https://techscoop.substack.com | https://techscoop.substack.com/feed | it-consulting | med | Published "Why Forward Deployed Engineers Are Becoming the Delivery Layer for Enterprise AI" tracking the Deloitte/IBM/Accenture/PwC FDE wave this quarter. Practitioner-level coverage of the delivery model restructuring story that W34's themes center on. Short, opinionated, consistent cadence. | rejected |
| Infrahive Blog | https://blog.infrahive.ai | https://blog.infrahive.ai/feed | it-consulting | med | Published "The Forward-Deployed Engineer Model: Why Consulting Is Dead for Enterprise AI Delivery" -- synthesizes the FDE wave across major firms with practitioner framing. Covers the delivery infrastructure shift at a level of specificity that Stratechery and Pragmatic Engineer don't. RSS feed unverified -- confirm on first run. | rejected |

### Batch 7 — Weekly Run (2026-08-10)

| Name | URL | RSS | Topic | Trust | Why Relevant | Status |
|------|-----|-----|-------|-------|--------------|--------|
| CyberArk Blog | https://www.cyberark.com/resources/blog/ | https://www.cyberark.com/resources/blog/feed/ | ai-agentic | high | Published "AI Agents and Identity Risks: How Security Will Shift in 2026" — primary source on non-human identity lifecycle management for AI agents. CyberArk (now part of Palo Alto after $25B acquisition) is the market standard for privileged access management and is publishing the most actionable agent identity guidance available. No comparable PAM/NHI source in current registry. | approved |
| Cloud Security Alliance Research | https://cloudsecurityalliance.org/research | https://cloudsecurityalliance.org/feed | ai-agentic | high | Published the definitive NHI governance whitepaper (Non-Human Identity Governance Vacuum) and the CISO note on AI agent governance framework gaps cited in W33 themes. Primary research org for enterprise AI security standards. Distinct from vendor blogs — independent, practitioner-verified. No CSA source currently in registry. | rejected |

### Batch 6 — Weekly Run (2026-07-27)

| Name | URL | RSS | Topic | Trust | Why Relevant | Status |
|------|-----|-----|-------|-------|--------------|--------|
| The New Stack | https://thenewstack.io | https://thenewstack.io/feed/ | it-consulting | high | Broke the AWS $1B forward-deployed engineering story this week and published the enterprise AI model routing analysis on Microsoft's MAI strategy. Consistent practitioner-level coverage of the delivery model shift. Fills a gap between Gartner (analyst) and Stratechery (strategic) with technical implementation depth. | rejected |
| Forward Deployed (Noah Brier) | https://www.forwarddeployed.com | https://www.forwarddeployed.com/feed | it-consulting | high | Substack dedicated to the intersection of AI, software development, and enterprise deployment. Directly tracks the FDE trend that drove W31's biggest theme. FDE job postings grew 729% YoY (643 to 5,330 Apr 2025 to Apr 2026). No comparable source in current registry focused specifically on embedded delivery models. | rejected |
| FinOps Foundation Blog | https://www.finops.org/updates/all-updates/ | https://www.finops.org/feed/ | it-consulting | high | The authoritative source for FinOps practice evolution. Published the 2026 State of FinOps report showing 98% of FinOps teams now manage AI spend and AI cost management is the #1 desired skillset. Directly relevant to the OpenAI token pricing shift and agent spend governance gap surfaced in W31. | rejected |
| The New Stack — AI | https://thenewstack.io/category/ai-ml/ | https://thenewstack.io/category/ai-ml/feed/ | ai-agentic | high | (Scoped feed for AI/ML coverage only from The New Stack. If the top-level feed is approved, this is redundant — note for David's review.) Technical depth on agentic AI architecture, agent security, and enterprise deployment patterns. Published the enterprise AI model routing analysis that frames the Microsoft MAI vs. OpenAI story. | rejected |
| Okta Newsroom / Security Blog | https://www.okta.com/blog/security/ | https://www.okta.com/blog/security/feed/ | ai-agentic | high | Published "AI Agents at Work 2026" — the most cited enterprise agent security dataset this week (53% out-of-scope, 47% security incident, 24.4% visibility). Okta is now a primary data source for agent identity and governance. RSS feed unverified — confirm on first run. | rejected |

### Batch 5 — Weekly Run (2026-07-20)

| Name | URL | RSS | Topic | Trust | Why Relevant | Status |
|------|-----|-----|-------|-------|--------------|--------|
| Oliver Patel — Enterprise AI Governance | https://oliverpatel.substack.com | https://oliverpatel.substack.com/feed | ai-agentic | high | Biweekly Substack compiling 80+ authoritative resources on agentic AI governance. Published the definitive resource guide on proportional governance this week — directly tied to W30 governance theme. No comparable governance-practitioner source in current registry. | rejected |
| The Texas Energy and Power Newsletter | https://www.texasenergyandpower.com | https://www.texasenergyandpower.com/feed | texas-regional | high | Weekly Substack covering Texas grid policy, ERCOT developments, clean energy, and utility regulation. Directly tracks the Abbott/PUC/ERCOT data center policy story and the large-load interconnection queue. Fills a dedicated grid-policy gap that Texas Tribune covers only occasionally. | rejected |
| Utility Dive | https://www.utilitydive.com | https://www.utilitydive.com/feeds/news/ | texas-regional | high | Leading trade publication for electric utility sector — broke the Texas 438 GW queue approval story this week. Covers grid interconnection policy, ERCOT regulatory actions, and data center power policy at a depth no other active source matches. | rejected |
| Gravitee — State of AI Agent Security | https://www.gravitee.io/blog | https://www.gravitee.io/blog/rss.xml | ai-agentic | med | Published the State of AI Agent Security 2026 Report (900+ exec/practitioner survey). Covers API security, agent identity, and governance gaps at a technical-practitioner level. Complements Gartner's governance analysis with field data. RSS feed unverified — confirm on first run. | rejected |
| CIO Dive | https://www.ciodive.com | https://www.ciodive.com/feeds/news/ | it-consulting | high | Industry publication covering CIO-level technology decisions, enterprise software, and AI governance. Broke the Gartner $234B SaaS agentic arbitrage story this week. High editorial bar, practitioner-focused, consistent publication cadence. Fills a gap between Gartner Newsroom (announcements only) and Stratechery (strategic analysis). | approved |

### Batch 4 — Weekly Run (2026-07-13)

| Name | URL | RSS | Topic | Trust | Why Relevant | Status |
|------|-----|-----|-------|-------|--------------|--------|
| Fast Company — Work Life | https://www.fastcompany.com/work-life | https://www.fastcompany.com/section/work-life/rss | it-consulting | high | Published the McKinsey layoffs warning analysis this week. Covers consulting talent model disruption, leadership and org design, and AI in the workplace at a practitioner-friendly level. Fills the business-culture layer between analyst reports and technical coverage. | rejected |
| Kai Waehner | https://www.kai-waehner.de/blog | https://www.kai-waehner.de/blog/feed | ai-agentic | high | Independent practitioner and Principal Technologist at Confluent. Published the 2026 Enterprise Agentic AI Landscape analysis on trust, flexibility, and vendor lock-in this week. Highly technical, architecture-level signal on agentic AI deployment decisions. No comparable practitioner-perspective source currently in registry. | rejected |
| Latitude Media | https://www.latitude.media | https://www.latitude.media/feed | texas-regional | high | Broke the ERCOT large-load queue quadrupling story surfaced in this week's themes. Covers energy infrastructure at the intersection of technology and grid policy. Directly relevant to Texas AI data center and power grid developments that matter for David's clients. | rejected |
| E&E News (POLITICO) | https://www.eenews.net | https://www.eenews.net/rss | texas-regional | high | Surfaced in the Abbott/ERCOT Texas data center grid analysis. Credible energy and environment policy coverage with a strong Texas angle. Published the "Texas governor talks tough on data centers" piece this week. Relevant for regulatory intelligence on the grid policy story. | rejected |
| Outsource Accelerator | https://www.outsourceaccelerator.com | https://www.outsourceaccelerator.com/feed | it-consulting | med | Covers IT services market dynamics, global delivery models, and the impact of AI on consulting and outsourcing. Published McKinsey layoffs AI consulting analysis this week with practitioner framing on talent repricing. Useful signal layer for competitive delivery model intelligence. | rejected |

### Batch 3 — Weekly Run (2026-07-06)

| Name | URL | RSS | Topic | Trust | Why Relevant | Status |
|------|-----|-----|-------|-------|--------------|--------|
| Matterfact | https://www.matterfact.com | https://www.matterfact.com/feed | it-consulting | high | Podcast newsletter focused specifically on IT services vs AI — covers consulting business model disruption, billable-hour breakdowns, and delivery model transformation. Surfaced the "Accenture model on trial" framing this week. High signal, consulting-specific. | rejected |
| Data Center Knowledge | https://www.datacenterknowledge.com | https://www.datacenterknowledge.com/rss.xml | texas-regional | med | Industry publication covering data center infrastructure, power, and policy. Published a Texas AI data centers coverage hub (power, policy, progress) that directly covers the Abbott/ERCOT regulatory developments David's clients need to understand. | rejected |
| Future of Consulting | https://futureofconsulting.ai | https://futureofconsulting.ai/feed | it-consulting | high | Dedicated to consulting industry AI transformation — specifically covers the delivery model bifurcation, billable-hours disruption, and outcome-based pricing. Surfaced the "Billions Spent, But the Old Pyramid Persists" analysis this week. No comparable source currently in registry. | rejected |
| AI Weekly | https://aiweekly.co | https://aiweekly.co/feed | ai-agentic | med | Alert-style newsletter covering AI business news with a strong consulting and enterprise lens. Surfaced McKinsey's 25% outcome-tied fee story and the billable-hours breakdown analysis this week. Fills a business-layer AI news gap between Import AI (technical) and Ben's Bites (product). | rejected |
| IBM Think | https://www.ibm.com/think | https://www.ibm.com/blogs/think/feed/ | it-consulting | high | IBM Consulting's editorial publication on business and technology transformation. Published the "forward deployed units" delivery model analysis this week — the IBM field model for scaling AI. High editorial bar, practitioner-focused, and directly competitive/complementary to Improving's delivery positioning. | rejected |

### Batch 2 — Weekly Run (2026-06-29)

| Name | URL | RSS | Topic | Trust | Why Relevant | Status |
|------|-----|-----|-------|-------|--------------|--------|
| MIT Technology Review — Making AI Work | https://www.technologyreview.com | https://www.technologyreview.com/feed | ai-agentic | high | MIT TR launched "Making AI Work" in Feb 2026 — a dedicated newsletter on applying LLMs and agentic AI across industries. High editorial standards, practitioner-focused, not hype-driven. Directly relevant to David's AI consulting conversations. | approved |
| BCG Insights (AI & Tech Services) | https://www.bcg.com/capabilities/artificial-intelligence | null | it-consulting | high | BCG's AI practice publishes primary research — the $200B agentic opportunity report, executive perspectives on AI and software futures. No RSS but search-based gather works. Essential for competitive intelligence on where the big firms are positioning. | approved |
| Stratechery | https://stratechery.com | https://stratechery.com/feed | it-consulting | high | Ben Thompson's analysis of how technology reshapes markets and business models — consistently the most rigorous strategic framing available for the AI/consulting bifurcation story. Not news; signal. | approved |
| AI Business Weekly | https://aibusinessweekly.net | https://aibusinessweekly.net/feed | ai-agentic | med | Daily newsletter written specifically for business leaders and executives — AI funding, product launches, enterprise deployments. 7 AM EST. Complements the technical depth of Import AI with executive-layer news. | rejected |
| Fort Worth Report | https://fortworthreport.org | https://fortworthreport.org/feed | texas-regional | high | Independent nonprofit local newsroom covering Fort Worth and Tarrant County. Broke the Wistron $761M AI facility story. Complements Dallas Innovates with west DFW coverage — the AllianceTexas corridor is now the AI infrastructure epicenter of the region. | rejected |

### Batch 1 — Weekly Run (2026-06-20)

| Name | URL | RSS | Topic | Trust | Why Relevant | Status |
|------|-----|-----|-------|-------|--------------|--------|
| AI Governance Institute | https://aigovernance.com/news | https://aigovernance.com/news/feed | ai-agentic | high | Publishes "AI Governance Weekly" — tracks agentic AI governance, enterprise rollback patterns, and regulatory frameworks. Directly feeds David's AI advisory conversations with clients. | approved |
| Turing Post | https://www.turingpost.com | https://www.turingpost.com/feed | ai-agentic | high | Regarded as the newsletter of record for AI governance, geopolitics, and open-source AI policy. High signal, low noise. Covers the "why this matters" layer above vendor news. | approved |
| Dallas Innovates | https://dallasinnovates.com | https://dallasinnovates.com/feed | texas-regional | high | Dedicated DFW innovation/tech coverage. Ranks DFW third nationally for tech job postings. Fills the local tech story gap that Dallas Morning News (search-only) misses on depth. | approved |
| Consulting Magazine | https://www.consultingmag.com | https://www.consultingmag.com/feed | it-consulting | med | Industry trade publication covering consulting firm news, M&A, delivery model trends, and market moves. Useful for tracking competitive landscape and mid-market bifurcation signals. | rejected |
| Agentic AI Institute | https://agenticaiinstitute.org | null | ai-agentic | med | Research-focused coverage of enterprise agentic AI adoption data (sourced the 72% production / 60% governance gap stats). No confirmed RSS but publishes regularly. Relevant for client-facing research grounding. | rejected |

---

## Approved — Moved to sources.yaml

### Batch 20 (partial) — Approved 2026-10-26

| Name | URL | Topic | Trust | Approved |
|------|-----|-------|-------|---------|
| InformationWeek | https://www.informationweek.com | it-consulting | med | 2026-10-26 |
| D CEO (D Magazine) | https://www.dmagazine.com/publications/d-ceo/ | texas-regional | med | 2026-10-26 |

### Batch 11 (partial) — Approved 2026-08-31

| Name | URL | Topic | Trust | Approved |
|------|-----|-------|-------|---------|
| The AI Optimist | https://www.aioptimist.org | leadership | med | 2026-08-31 |

### Batch 10 (partial) — Approved 2026-08-24

| Name | URL | Topic | Trust | Approved |
|------|-----|-------|-------|---------|
| CEOWORLD Magazine | https://ceoworld.biz | leadership | med | 2026-08-24 |
| Prosci Blog | https://www.prosci.com/blog | leadership | high | 2026-08-24 |

### Batch 5 — Approved 2026-07-20

| Name | URL | Topic | Trust | Approved |
|------|-----|-------|-------|---------|
| CIO Dive | https://www.ciodive.com | it-consulting | high | 2026-07-20 |

### Batch 2 — Approved 2026-06-29

| Name | URL | Topic | Trust | Approved |
|------|-----|-------|-------|---------|
| MIT Technology Review — Making AI Work | https://www.technologyreview.com | ai-agentic | high | 2026-06-29 |
| BCG Insights (AI & Tech Services) | https://www.bcg.com/capabilities/artificial-intelligence | it-consulting | high | 2026-06-29 |
| Stratechery | https://stratechery.com | it-consulting | high | 2026-06-29 |

### Batch 1 — Approved 2026-06-20

| Name | URL | Topic | Trust | Approved |
|------|-----|-------|-------|---------|
| AI Governance Institute | https://aigovernance.com/news | ai-agentic | high | 2026-06-20 |
| Turing Post | https://www.turingpost.com | ai-agentic | high | 2026-06-20 |
| Dallas Innovates | https://dallasinnovates.com | texas-regional | high | 2026-06-20 |

### Batch 0 — Approved 2026-06-19

All 10 entries approved by David on 2026-06-19. Moved to `sources.yaml` with `status: active`, `added: 2026-06-19`.

| Name | URL | Topic | Trust | Approved |
|------|-----|-------|-------|---------|
| The Pragmatic Engineer | https://newsletter.pragmaticengineer.com | it-consulting | high | 2026-06-19 |
| Import AI (Jack Clark) | https://importai.substack.com | ai-agentic | high | 2026-06-19 |
| Ben's Bites | https://bensbites.beehiiv.com | ai-agentic | med | 2026-06-19 |
| Texas Tribune | https://www.texastribune.org | texas-regional | high | 2026-06-19 |
| Dallas Morning News — Business | https://www.dallasnews.com/business | texas-regional | med | 2026-06-19 |
| Gartner Newsroom | https://www.gartner.com/en/newsroom | it-consulting | high | 2026-06-19 |
| The Information | https://www.theinformation.com | ai-agentic | high | 2026-06-19 |
| Hacker News (top stories) | https://news.ycombinator.com | ai-agentic | med | 2026-06-19 |
| Axios Pro — Tech | https://www.axios.com/pro/tech-deals | it-consulting | med | 2026-06-19 |
| EOS Worldwide Blog | https://www.eosworldwide.com/blog | leadership | med | 2026-06-19 |

Also added by David as named sources (approved same session, 2026-06-19):

| Name | URL | Topic | Trust | Approved |
|------|-----|-------|-------|---------|
| Superhuman AI | https://www.superhuman.ai | ai-agentic | med | 2026-06-19 |
| The Rundown AI | https://www.therundown.ai | ai-agentic | med | 2026-06-19 |
| NVIDIA Newsroom | https://nvidianews.nvidia.com | ai-agentic | high | 2026-06-19 |
| OpenAI News | https://openai.com/news/ | ai-agentic | high | 2026-06-19 |
| Anthropic News | https://www.anthropic.com/news | ai-agentic | high | 2026-06-19 |
| xAI News | https://x.ai/news | ai-agentic | high | 2026-06-19 |
| Google DeepMind / Google AI Blog | https://blog.google/technology/ai/ | ai-agentic | high | 2026-06-19 |
| Meta AI Blog | https://ai.meta.com/blog/ | ai-agentic | med | 2026-06-19 |
| Microsoft AI Blog | https://blogs.microsoft.com/ai/ | ai-agentic | high | 2026-06-19 |

---

## Rejected

### Batch 20 (partial) — 2026-10-26

| Name | URL | Topic | Reason |
|------|-----|-------|--------|
| Microsoft Security Blog | https://www.microsoft.com/en-us/security/blog/ | ai-agentic | Rejected by David 2026-10-26 |
| SecurityWeek | https://www.securityweek.com | ai-agentic | Rejected by David 2026-10-26 |
| Perceptyx Blog | https://blog.perceptyx.com | leadership | Rejected by David 2026-10-26 |

### Batch 11 (partial) — 2026-08-31

| Name | URL | Topic | Reason |
|------|-----|-------|--------|
| AI Leadership Weekly | https://aileadershipweekly.com | leadership | Rejected by David 2026-08-31 |
| The Crossing Report | https://crossing.one | it-consulting | Rejected by David 2026-08-31 |
| Chief Reinvention Officer | https://chiefreinventionofficer.com/blog-page | it-consulting | Rejected by David 2026-08-31 |
| Consultancy.uk | https://www.consultancy.uk | it-consulting | Rejected by David 2026-08-31 |

### Batch 10 (partial) — 2026-08-24

| Name | URL | Topic | Reason |
|------|-----|-------|--------|
| Josh Bersin | https://joshbersin.com | leadership | Rejected by David 2026-08-24 |
| DDI (Development Dimensions International) | https://www.ddi.com/blog | leadership | Rejected by David 2026-08-24 |

### Batch 9 — 2026-08-24

| Name | URL | Topic | Reason |
|------|-----|-------|--------|
| The EU AI Act Newsletter | https://artificialintelligenceact.substack.com | ai-agentic | Rejected by David 2026-08-24 |
| Texas Impact | https://texasimpact.substack.com | texas-regional | Rejected by David 2026-08-24 |
| Responsible AI Labs | https://responsibleailabs.ai | ai-agentic | Rejected by David 2026-08-24 |

### Batch 8 — 2026-08-17

| Name | URL | Topic | Reason |
|------|-----|-------|--------|
| Data Center Frontier | https://www.datacenterfrontier.com | texas-regional | Rejected by David 2026-08-17 |
| TechScoop (Substack) | https://techscoop.substack.com | it-consulting | Rejected by David 2026-08-17 |
| Infrahive Blog | https://blog.infrahive.ai | it-consulting | Rejected by David 2026-08-17 |

### Batch 6 — 2026-08-03

| Name | URL | Topic | Reason |
|------|-----|-------|--------|
| The New Stack | https://thenewstack.io | it-consulting | Rejected by David 2026-08-03 |
| Forward Deployed (Noah Brier) | https://www.forwarddeployed.com | it-consulting | Rejected by David 2026-08-03 |
| FinOps Foundation Blog | https://www.finops.org/updates/all-updates/ | it-consulting | Rejected by David 2026-08-03 |
| The New Stack — AI | https://thenewstack.io/category/ai-ml/ | ai-agentic | Rejected by David 2026-08-03 |
| Okta Newsroom / Security Blog | https://www.okta.com/blog/security/ | ai-agentic | Rejected by David 2026-08-03 |

### Batch 4 — 2026-08-03

| Name | URL | Topic | Reason |
|------|-----|-------|--------|
| Fast Company — Work Life | https://www.fastcompany.com/work-life | it-consulting | Rejected by David 2026-08-03 |
| Kai Waehner | https://www.kai-waehner.de/blog | ai-agentic | Rejected by David 2026-08-03 |
| Latitude Media | https://www.latitude.media | texas-regional | Rejected by David 2026-08-03 |
| E&E News (POLITICO) | https://www.eenews.net | texas-regional | Rejected by David 2026-08-03 |
| Outsource Accelerator | https://www.outsourceaccelerator.com | it-consulting | Rejected by David 2026-08-03 |

### Batch 5 — 2026-07-20

| Name | URL | Topic | Reason |
|------|-----|-------|--------|
| Oliver Patel — Enterprise AI Governance | https://oliverpatel.substack.com | ai-agentic | Rejected by David 2026-07-20 |
| The Texas Energy and Power Newsletter | https://www.texasenergyandpower.com | texas-regional | Rejected by David 2026-07-20 |
| Utility Dive | https://www.utilitydive.com | texas-regional | Rejected by David 2026-07-20 |
| Gravitee — State of AI Agent Security | https://www.gravitee.io/blog | ai-agentic | Rejected by David 2026-07-20 |

### Batch 3 — 2026-07-06

| Name | URL | Topic | Reason |
|------|-----|-------|--------|
| Matterfact | https://www.matterfact.com | it-consulting | Rejected by David 2026-07-06 |
| Data Center Knowledge | https://www.datacenterknowledge.com | texas-regional | Rejected by David 2026-07-06 |
| Future of Consulting | https://futureofconsulting.ai | it-consulting | Rejected by David 2026-07-06 |
| AI Weekly | https://aiweekly.co | ai-agentic | Rejected by David 2026-07-06 |
| IBM Think | https://www.ibm.com/think | it-consulting | Rejected by David 2026-07-06 |

### Batch 2 — 2026-06-29

| Name | URL | Topic | Reason |
|------|-----|-------|--------|
| AI Business Weekly | https://aibusinessweekly.net | ai-agentic | Rejected by David 2026-06-29 |
| Fort Worth Report | https://fortworthreport.org | texas-regional | Rejected by David 2026-06-29 |

### Batch 13 — 2026-09-11

| Name | URL | Topic | Reason |
|------|-----|-------|--------|
| ISACA Now Blog | https://www.isaca.org/resources/news-and-trends/isaca-now-blog | ai-agentic | Rejected by David 2026-09-11 |
| Harvard Business Review — CIO section | https://hbr.org/topic/subject/it-management | it-consulting | Rejected by David 2026-09-11 |
| Constellation Research Blog | https://www.constellationr.com/blog-news | it-consulting | Rejected by David 2026-09-11 |
| SiliconAngle (theCUBE) | https://siliconangle.com | ai-agentic | Rejected by David 2026-09-11 |
| Andreessen Horowitz (a16z) — Enterprise AI | https://a16z.com/tag/enterprise/ | ai-agentic | Rejected by David 2026-09-11 |

### Batch 1 — 2026-06-20

| Name | URL | Topic | Reason |
|------|-----|-------|--------|
| Consulting Magazine | https://www.consultingmag.com | it-consulting | Rejected by David 2026-06-20 |
| Agentic AI Institute | https://agenticaiinstitute.org | ai-agentic | Rejected by David 2026-06-20 |
<!-- system:end -->

<!-- personal:start -->
<!-- personal:end -->

### Batch 14 — Weekly Run (2026-09-14)

| Name | URL | RSS | Topic | Trust | Why Relevant | Status |
|------|-----|-----|-------|-------|--------------|--------|
| Kyndryl Insights | https://www.kyndryl.com/us/en/insights | null | it-consulting | high | Primary publisher of enterprise AI value realization and workforce readiness research in 2026. Directly sourced W38 Theme 1: published "Why Value Realization Is Key to Achieving ROI in 2026" and the Kyndryl People Readiness Report (only 23% of workforces AI-ready). Practitioner-level, consistent publication cadence, no vendor-product bias in editorial framing. No confirmed RSS; gather_method: search via site:kyndryl.com/us/en/insights. | approved 2026-09-14 |
| AIIM | https://info.aiim.org | null | leadership | high | Published the 2026 AIIM Industry Watch — work, skills, and identity of the information professional — generating the highest participation in the organization's research history. Directly sourced W38 Theme 2 on professional identity compression and intuition rust. Primary practitioner research org for information management and AI adoption. Distinct from Prosci (change management lens) and CEOWORLD (exec generalist). No confirmed RSS; gather_method: search via site:aiim.org. | rejected 2026-09-14 |
| CBRE Tech Talent Research | https://www.cbre.com/insights/reports/scoring-tech-talent | null | texas-regional | high | Annual "Scoring Tech Talent" report is the authoritative market-level data on tech hiring by metro. Directly sourced W38 Theme 3: DFW's 37,230 net new tech workers (2022-2025) and #8 ranking in North America. No RSS; single annual report but cited by every DFW talent story. Gather_method: search via site:cbre.com/insights. | rejected 2026-09-14 |
| Employer Branding News | https://employerbranding.news | null | leadership | med | Published "The Real AI Threat at Work May Be Identity, Not Redundancy" — directly tied to W38 Theme 2 professional identity angle. Covers the intersection of AI, workforce identity, and employer strategy from a practitioner/HR leadership perspective. Distinct from academic research (ScienceDirect) and change management (Prosci). No confirmed RSS; gather_method: search via site:employerbranding.news. | rejected 2026-09-14 |
| Kyndryl Wire (news) | https://www.kyndryl.com/us/en/about-us/news | null | it-consulting | high | Separate from Kyndryl Insights — the Wire covers enterprise IT partnership announcements, delivery model moves (AWS, Microsoft, SAP partnerships), and infrastructure strategy. Published "Kyndryl launches AI orchestration capability for enterprises" and the AWS enterprise modernization story. Fills the delivery-model intelligence gap between Kyndryl's editorial (Insights) and trade press. No confirmed RSS; gather_method: search. | approved 2026-09-14 |

### Batch 16 — Weekly Run (2026-09-28)

| Name | URL | RSS | Topic | Trust | Why Relevant | Status |
|------|-----|-----|-------|-------|--------------|--------|
| Thomson Reuters Institute | https://www.thomsonreuters.com/en-us/posts/technology/ | https://www.thomsonreuters.com/en-us/posts/feed/ | it-consulting | high | Published the 2026 AI in Professional Services Report: organization-wide AI usage nearly doubled to 40%, junior talent crisis explicitly named as an unresolved gap. Primary research source for the consulting talent restructuring story (W40 Theme 3). Independent research arm of Thomson Reuters — distinct from vendor reports and analyst firms. Editorial bar is high, annual report is widely cited by professional services leadership. RSS feed unverified — confirm on first run. | rejected 2026-09-28 |
| RSM US Insights | https://rsmus.com/insights | null | it-consulting | high | Published "Professional services firms are redefining talent strategy in the age of AI" — practitioner-level mid-market advisory covering talent, AI adoption, and delivery model shifts. Distinct from Big 4 research (BCG, Deloitte, PwC) with focus on the sub-enterprise professional services segment. Directly relevant to W40 Theme 3 (consulting restructuring and talent pipeline). No RSS confirmed; gather_method: search via site:rsmus.com/insights. | rejected 2026-09-28 |
| Help Net Security | https://www.helpnetsecurity.com | https://www.helpnetsecurity.com/feed/ | ai-agentic | high | Primary source for the AWS Reimagine 2026 AI agent governance report (W40 Theme 1 — shadow AI at enterprise scale). Daily security intelligence publication covering enterprise AI agent security, identity governance, and shadow AI adoption. High editorial bar, CISO-audience focus, consistent publication cadence. Fills a gap between CyberArk (vendor blog) and CSA (standards body) with independent daily security journalism. RSS feed likely active — confirm on first run. | rejected 2026-09-28 |
| Airia Blog | https://airia.com/blog | null | ai-agentic | med | Published "Shadow AI Statistics: Key Data Points Every CISO Needs in 2026" — the most comprehensive shadow AI adoption statistics source this week (45.6% of orgs unaware of workforce AI adoption rate, incident data by sector). Practitioner-security lens distinct from policy-focused governance coverage. No RSS confirmed; gather_method: search via site:airia.com/blog. | rejected 2026-09-28 |
| DEC Network | https://thedec.co | null | texas-regional | med | Organizes DFW Startup Week and publishes ecosystem-focused content on Dallas-Fort Worth founders, investors, and entrepreneurship infrastructure. Dallas jumped to No. 27 in the Global Startup Ecosystem Report — DEC Network is the primary organizer driving the startup-formation layer that David's steering explicitly asks for (DFW ecosystem beyond data centers). No RSS confirmed; gather_method: search via site:thedec.co. | approved 2026-09-28 |

### Batch 18 — Weekly Run (2026-10-12)

| Name | URL | RSS | Topic | Trust | Why Relevant | Status |
|------|-----|-----|-------|-------|--------------|--------|
| Forrester Research Blog | https://www.forrester.com/blogs/ | https://www.forrester.com/blogs/feed/ | ai-agentic | high | Published "Identiverse 2026 Recap: Identity Security for Agentic AI Dominates" — the primary analyst voice on non-human identity governance and AI agent security frameworks. Covers the intersection of Entra ID, NHI lifecycle, and agent provisioning that directly underpins W42 Theme 1 (Google Gemini agent-as-employee model). Distinct from CyberArk (vendor) and CIO Dive (trade press) with analyst-grade rigor. RSS feed unverified — confirm on first run. | rejected 2026-10-19 |
| PwC Insights | https://www.pwc.com/gx/en/insights.html | null | it-consulting | high | Published the 2026 CEO Survey (primary source: 56% of CEOs reported no revenue growth or cost reduction from AI) and rated as a Leader in Forrester Wave AI Consulting Services Q2 2026. Primary competitor intelligence and client-conversation data for W42 Theme 2 (the 5% ROI gap). No RSS confirmed; gather_method: search via site:pwc.com/gx/en/insights. | rejected 2026-10-19 |
| Saviynt Blog | https://saviynt.com/blog | null | ai-agentic | med | Published the 2026 CISO AI Risk Report (235 security leaders: 71% say AI tools already reach core enterprise systems, only 16% govern that access). Practitioner-level identity governance and AI agent security coverage. Directly ties to W42 Theme 1 on agent identity and access provisioning. Fills a gap between Forrester (analyst) and CyberArk (vendor-specific) with independent practitioner survey data. No RSS confirmed; gather_method: search via site:saviynt.com/blog. | rejected 2026-10-19 |
| Wharton at Work | https://executiveeducation.wharton.upenn.edu/thought-leadership/wharton-at-work/ | null | leadership | high | Published "Beyond the AI Pilot: How Executives Lead AI Transformation" (October 2026) — directly relevant to W42 Theme 2, distinguishing pilot success from operating-model change. Practitioner-accessible research from Wharton faculty on AI leadership, accountability structures, and executive decision-making. Distinct from HBR (broader editorial) with Wharton faculty research grounding. No RSS confirmed; gather_method: search via site:executiveeducation.wharton.upenn.edu/thought-leadership. | rejected 2026-10-19 |
| Dallas Venture Deals | https://dallasventuredeals.beehiiv.com | https://dallasventuredeals.beehiiv.com/feed | texas-regional | med | Weekly newsletter tracking DFW VC deal flow — rounds, valuations, and investors. Direct source for DFW capital intelligence at the deal level (Island's $400M Series F, Q3 rebound data) that Dallas Innovates covers at a higher editorial level. Fills the gap between broad DFW tech coverage and specific investment transaction data. RSS feed unverified — confirm on first run. | rejected 2026-10-19 |

### Batch 17 — Weekly Run (2026-10-05)

| Name | URL | RSS | Topic | Trust | Why Relevant | Status |
|------|-----|-----|-------|-------|--------------|--------|
| TechTarget AI | https://www.techtarget.com/ai | https://www.techtarget.com/ai/rss/AllAIContent.xml | ai-agentic | high | Published "Key enterprise strategies for AI agent observability" (Sept 9, 2026) — three-pillar framework (intent, method, outcome) directly applicable to W41 Theme 1 agent governance stack. Practitioner-depth coverage of enterprise AI infrastructure decisions. Fills a gap between CIO Dive (editorial) and Dataiku (vendor) with independent technical guidance for IT decision-makers. RSS feed unverified — confirm on first run. | rejected 2026-10-19 |
| Monte Carlo Blog | https://www.montecarlodata.com/blog | https://www.montecarlodata.com/blog/feed/ | ai-agentic | high | Published "The 2026 Guide to Agent Observability Tools" and surveyed enterprises building agents in production — 73% won't ship without monitoring in place, 53% expect to redesign agents already deployed. Primary practitioner research source on agent monitoring and data reliability for production AI. Distinct from governance/policy coverage with operational depth. RSS feed unverified — confirm on first run. | rejected 2026-10-19 |
| Venture Dallas | https://www.venturedallas.org | null | texas-regional | high | Nonprofit organizing DFW's premier annual VC and startup event (Nov 4-8, 1,500+ attendees). Covers DFW investment activity, startup funding rounds, and institutional capital moves. Direct source for DFW capital layer intelligence that Dallas Innovates covers at a higher level. No RSS confirmed; gather_method: search via site:venturedallas.org and event coverage. | rejected 2026-10-19 |
| DFW Startup Week | https://dfwstartupweek.com | null | texas-regional | med | Annual event covering the DFW startup and entrepreneurship ecosystem — runs across 15+ Texas cities. Published ecosystem data on founders, investors, and support organizations. Distinct from Venture Dallas (institutional VC) with broader founder-layer coverage. Dallas Innovates covers the event but this is the primary source. No RSS confirmed; gather_method: search via site:dfwstartupweek.com. | rejected 2026-10-19 |
| McKinsey People & Org Practice | https://www.mckinsey.com/capabilities/people-and-organizational-performance/our-insights | null | leadership | high | Publishes State of Organizations annual report (2026 edition directly sourced W41 Theme 2 — 86% readiness gap, 14% consistent AI champions, 1-in-6 orgs with no C-level AI owner). Distinct from general McKinsey AI content with organizational performance and leadership research focus. Annual report alone justifies monitoring. No RSS confirmed; gather_method: search via site:mckinsey.com/capabilities/people-and-organizational-performance. | rejected 2026-10-19 |

### Batch 15 — Weekly Run (2026-09-22)

| Name | URL | RSS | Topic | Trust | Why Relevant | Status |
|------|-----|-----|-------|-------|--------------|--------|
| Futurum Group | https://futurumgroup.com | https://futurumgroup.com/feed/ | it-consulting | high | Published "Are Outcome-Based and Hybrid AI Pricing Models Rewriting the Vendor Playbook?" directly tied to W39 Theme 1 (rate card / outcome-based pricing shift). Independent analyst firm covering enterprise technology markets including IT services pricing evolution. Fills a gap between Gartner (broad analyst) and Stratechery (strategic narrative) with dedicated enterprise pricing and vendor model coverage. RSS feed unverified — confirm on first run. | rejected 2026-10-19 |
| Culture Amp Blog | https://www.cultureamp.com/blog | null | leadership | high | Published "Organizational change management for the AI era" covering the adoption gap SHRM's 2026 workplace survey identified (34% of workers still not using AI tools). Practitioner-focused people analytics and culture platform. Directly relevant to W39 Theme 2 (culture as the constraint) and David's human-side-of-AI lens. No RSS confirmed; gather_method: search via site:cultureamp.com/blog. | rejected 2026-10-19 |
| Culture Partners | https://culturepartners.com/insights | null | leadership | high | Published "Change Management Trends in 2026" covering how leaders support employees through role evolution, new AI processes, and skills development. Research-backed culture change advisory. Distinct from Prosci (process methodology) with organizational behavior research focus. No RSS confirmed; gather_method: search via site:culturepartners.com/insights. | rejected 2026-10-19 |
| Deloitte Insights — Human Capital | https://www.deloitte.com/us/en/insights/topics/talent/human-capital-trends.html | null | leadership | high | Published the 2026 Global Human Capital Trends report: 65% of organizations believe their culture needs significant change because of AI, only 5% report making great progress on it. Primary annual practitioner research report on talent, culture, and AI adoption at global scale. Distinct from Deloitte's AI consulting practice announcements — this is independent research. No subcategory RSS; gather_method: search via site:deloitte.com/us/en/insights/topics/talent. | rejected 2026-10-19 |
| Rocketlane Blog | https://www.rocketlane.com/blogs | https://www.rocketlane.com/blogs/rss.xml | it-consulting | med | Published "AI in PS Delivery: What Works in 2026" covering how professional services teams are restructuring delivery around AI productivity gains. Directly tied to W39 Theme 1 on operating model evolution in IT services. Practitioner-level coverage of project delivery, resource models, and AI integration in PS firms. No RSS confirmed; gather_method: search via site:rocketlane.com/blogs. | rejected 2026-10-19 |

### Batch 13 — Weekly Run (2026-09-11)

| Name | URL | RSS | Topic | Trust | Why Relevant | Status |
|------|-----|-----|-------|-------|--------------|--------|
| ISACA Now Blog | https://www.isaca.org/resources/news-and-trends/isaca-now-blog | null | ai-agentic | high | Primary practitioner resource for IT audit, risk, and governance professionals. Directly covers the CIO accountability and AI governance gap themes surfaced this week — published frameworks on AI accountability assignment and governance ownership. Fills a gap between HBR (leadership lens) and CyberArk (security lens) with the governance-professional practitioner view. No public RSS; gather_method: search via site:isaca.org. | rejected 2026-09-11 |
| Harvard Business Review — CIO section | https://hbr.org/topic/subject/it-management | null | it-consulting | high | HBR's IT management coverage captures the CIO career-risk and accountability gap stories at the intersection of business strategy and technology leadership. Distinct from the AI/ML section already tracked — this covers the organizational dynamics around technology leadership decisions. No subcategory RSS; gather_method: search via site:hbr.org/topic/subject/it-management. | rejected 2026-09-11 |
| Constellation Research Blog | https://www.constellationr.com/blog-news | null | it-consulting | high | Independent technology research and advisory firm. Covers enterprise AI strategy, the adoption-vs-production gap, and consulting delivery model shifts at a practitioner depth comparable to Gartner but with faster publication cadence. Published analysis of enterprise agentic AI deployment patterns in 2026. No confirmed RSS; gather_method: search via site:constellationr.com. | rejected 2026-09-11 |
| SiliconAngle (theCUBE) | https://siliconangle.com | https://siliconangle.com/feed/ | ai-agentic | med | Breaking enterprise technology news with strong AI and cloud coverage. Published real-time analysis of the Nvidia/Hugging Face acquisition and Deloitte AI practice announcements this week. Fills the fast-news gap between CIO Dive (editorial) and Hacker News (community aggregation) with vendor-announcement depth. RSS feed unverified — confirm on first run. | rejected 2026-09-11 |
| Andreessen Horowitz (a16z) — Enterprise AI | https://a16z.com/tag/enterprise/ | null | ai-agentic | high | Published the 2026 enterprise AI adoption benchmarks that underpin the Forrester and Agentic AI Institute findings on adoption theater vs. real production. Primary VC-lens source on what enterprise AI maturity actually looks like across portfolio companies at scale. No dedicated RSS for enterprise tag; gather_method: search via site:a16z.com/tag/enterprise. | rejected 2026-09-11 |

### Batch 19 — Weekly Run (2026-10-19)

| Name | URL | RSS | Topic | Trust | Why Relevant | Status |
|------|-----|-----|-------|-------|--------------|--------|
| Power Platform Stacks | https://powerplatstack.substack.com | https://powerplatstack.substack.com/feed | ai-agentic | high | Substack newsletter publishing weekly Microsoft Power Platform and Copilot Studio roundups. Published the Oct 3-16 edition that first surfaced W43 Theme 1 technical detail: Copilot Studio agent accounts (Entra Agent ID auto-provisioning, no opt-out since July 2026, shared memory, new licensing model). Fills a gap in registry for Microsoft-specific practitioner coverage at the platform/governance layer. RSS via Substack — unverified but standard. | rejected 2026-10-19 |
| OutSystems Research | https://www.outsystems.com/news/ | null | ai-agentic | high | Published primary W43 source: Agentic AI Enterprise Readiness research (Oct 15, 2026) — 850+ IT decision-makers, 96% using agents, 94% concerned about sprawl, only 26% prepared for agent conflicts. Independent enterprise research arm of OutSystems (low-code platform). Consistent large-sample enterprise AI research; prior editions covered developer and digital experience trends. Distinct from vendor analyst reports — primary survey data with methodology disclosed. No RSS confirmed; gather_method: search via site:outsystems.com/news. | rejected 2026-10-19 |
| isolved Research | https://www.isolvedhcm.com/resources/research | null | leadership | high | Published the W43 primary source for Theme 3: HR Leaders Report on AI Expectations vs. Capacity (Oct 14, 2026) — 1,005 HR decision-makers, strategic AI expectations outpacing people leader capacity. HR technology and workforce platform with an independent research practice. Fills a gap for primary HR/workforce + AI data — distinct from SHRM (membership org), Gartner (broad analyst), and McKinsey (strategy lens). No RSS confirmed; gather_method: search via site:isolvedhcm.com/resources. | rejected 2026-10-19 |
| HPCwire AiWire | https://www.hpcwire.com/category/ai/ | https://www.hpcwire.com/feed/ | ai-agentic | med | Published "The Future of Enterprise AI Isn't a Super-Agent, It's an Agentic Workforce" (Oct 14, 2026) — architectural argument that enterprise AI value comes from coordinating specialized agents, not building general agents. Covers enterprise AI infrastructure and compute layer at practitioner depth. Fills a coverage gap between general AI news (TechCrunch) and Microsoft-specific coverage — useful for the architectural/technical layer of agentic AI deployments. RSS feed standard — unverified confirm on first run. | rejected 2026-10-19 |
| Peafowlit Blog | https://peafowlit.com/blog | null | ai-agentic | med | Published "Power Platform Agent Governance: October 2026 Status Guide" covering Copilot Studio agent account governance implications — MFA gaps, admin controls, and deployment checklist for M365 admins. Microsoft Power Platform practitioner blog with governance and security focus. Distinct from Power Platform Stacks (news/roundup) — this covers implementation guidance. Directly relevant to Improving's Microsoft practice clientele. No RSS confirmed; gather_method: search via site:peafowlit.com/blog. | rejected 2026-10-19 |

### Batch 20 — Weekly Run (2026-10-26)

| Name | URL | RSS | Topic | Trust | Why Relevant | Status |
|------|-----|-----|-------|-------|--------------|--------|
| Microsoft Security Blog | https://www.microsoft.com/en-us/security/blog/ | https://www.microsoft.com/en-us/security/blog/feed/ | ai-agentic | high | Primary source for W44 Theme 1: Microsoft's Oct 19 "Agents are your newest insiders" post (Dynamic Permissions, Dynamic Agent Risk, Guardian Agents). Default-stack source for Entra, Defender and agent governance announcements, ahead of third-party coverage. Feed responds live; not parsed in full. | rejected 2026-10-26 |
| SecurityWeek | https://www.securityweek.com | https://www.securityweek.com/feed/ | ai-agentic | high | Independent reporting on the Microsoft agent-insider announcement (Oct 20) plus a steady stream of agent-security items (rogue agent incidents, agentic SecOps funding). Feed verified live 2026-10-26 with items from the past 24 hours. Fills the independent-trade gap between vendor blogs and analyst firms. | rejected 2026-10-26 |
| InformationWeek | https://www.informationweek.com | null | it-consulting | med | Published the "identity is only part of the answer" argument on agent governance this month, aimed at IT leaders. Practitioner-decision-maker angle on CIO and governance topics. RSS not confirmed; gather_method: search via site:informationweek.com. | approved 2026-10-26 |
| Perceptyx Blog | https://blog.perceptyx.com | null | leadership | med | Publishes employee-survey data on AI and culture (2,800+ employee survey: 33% report AI-created tension between teams). Human-side-of-AI lens that matches the push_toward steering on culture, trust and adoption. No RSS confirmed; vendor-affiliated, so treat as data source, not editorial. | rejected 2026-10-26 |
| D CEO (D Magazine) | https://www.dmagazine.com/publications/d-ceo/ | null | texas-regional | med | Dallas business leadership magazine; October 2026 issue profiles a decade of Dallas Innovates. Adds DFW business and leadership stories beyond data centers and capital markets, per steering. No RSS confirmed; gather_method: search via site:dmagazine.com. | approved 2026-10-26 |
