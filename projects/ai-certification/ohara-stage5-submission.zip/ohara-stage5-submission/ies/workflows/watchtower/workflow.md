---
name: watchtower
description: Standing intelligence monitor — scans news and sources across David's topic areas, delivers daily awareness summaries, and surfaces weekly content candidates feeding the existing content pipeline.
agent: knox
evolution: personal
model: sonnet
---

<!-- system:start -->
# Watchtower Workflow

Standing intelligence system. Monitors AI/agentic systems, IT consulting, and Texas/regional business. Two entry modes with distinct outputs.

**Harper is consulted during the weekly content-flagging step (step-02 of weekly run) for voice alignment. Tweet generation (step-02b) reads `identity/VOICE.md` directly and is executed by Knox.**

**SLACK RULE — NO EXCEPTIONS:** All Slack operations (posting drafts, sending to `#content`, any channel message) use the **master-slack skill**. Do NOT look for a Slack MCP connector. Do NOT suggest authentication for a connector. Do NOT use any other path. The master-slack skill is the only authorized method.

---

## Entry Modes

| Mode | Trigger | Cadence | Steps |
|------|---------|---------|-------|
| **Daily / Awareness** | Invoked by `workflows/boot/` step-04.5 (full boot) or by `workflows/morning-briefing/` (standalone briefing) | Once per day, via boot or the morning briefing | daily-step-01 through daily-step-07-prune, then daily-step-06 |
| **Weekly / Content + Sources** | "run watchtower weekly" or scheduled Monday 7am (pending) | Every Monday | weekly-step-01 through weekly-step-05 |

**Daily cadence note:** The daily run does NOT run as a standalone scheduled task. It is invoked by boot step-04.5 (`workflows/boot/steps/step-04.5-watchtower-daily-handoff.md`) or by the morning-briefing workflow. See `config.yaml cadence.daily.enabled: false` and the WATCHTOWER INVOCATION section in `workflows/morning-briefing/workflow.md`. The seen.jsonl ledger and `Watchtower/Daily/` notes are written only by this daily run.

Both modes share `state.yaml` and `config.yaml`. Sources live in `sources.yaml`.

---

## Data Sources Required

| Source | Purpose | Path / Connector |
|--------|---------|-----------------|
| `sources.yaml` | Active RSS feeds + trusted web sources | `workflows/watchtower/sources.yaml` |
| `config.yaml` | Thresholds, paths, cadence, profile | `workflows/watchtower/config.yaml` |
| `state.yaml` | Run state and accumulated context | `workflows/watchtower/state.yaml` |
| `seen.jsonl` | Dedupe ledger | `workflows/watchtower/seen.jsonl` (created on first run) |
| `source-activity.json` | Per-source last_surfaced ledger for dormancy tracking | `workflows/watchtower/source-activity.json` |
| `dormant-sources.yaml` | Retired sources (not polled, not deleted) | `workflows/watchtower/dormant-sources.yaml` |
| David's profile | Lenses for scoring | `identity/VOICE.md`, `identity/MEMORY.md` |
| Content register | Append content candidates | `reference/blog-ideas.md` |
| Obsidian vault | Daily notes + content drafts | Obsidian vault (`Watchtower/Daily/`, `Mind/`); write method per `state.yaml` `obsidian_write_method` |

---

## STATE CHECK

Read and follow `reference/state-check-protocol.md` before any execution. Workflow: `watchtower`; agent: `knox`.

**Variant:** daily and weekly share this `state.yaml`.
- On a fresh run, determine the entry mode from the trigger (daily vs weekly) and begin at step-01 for that mode. A fresh run in either mode writes only the header fields (`status`, `session-id`, `session-started`, `original-request`, `current-step`) and never clears `accumulated-context`: `content_queue` is append-only until weekly-step-05 clears it, and `obsidian_write_method`, `pending_batches`, and `sources_added_to_registry` persist across runs.
- `session-id` names the mode: `wt-daily-YYYY-MM-DD`, `wt-weekly-YYYY-Www`. A `status: complete` run whose `session-id` is `wt-daily-<today>` means the daily run already ran today; do not run it again.
- An `in-progress` run is resumed only when its mode matches the requested mode and `session-started` is under 4 hours old. Otherwise treat it as stale and start fresh in the requested mode.
- On abort, surface to David.

---

## EXECUTION

Run STATE CHECK above, then begin at step-01 for the appropriate mode.

---

## EVAL RECORD (daily run)

The daily run is invoked from inside another workflow (boot step-04.5 or morning-briefing), so it has no user prompt. Before 2026-10-26 that meant it produced no real eval record: its cost was invisible in the parent's totals and the only artifact was a zero-step record quarantined to `runs/_phantoms/` (eval-20261026T142940-SP53MK). Record the run explicitly, the way daily-review and dream-cycle do:

1. **Open the record** at the start of a fresh daily run, after STATE CHECK decides fresh and before `daily-step-01`:
   ```bash
   python3 systems/eval-harness/new-eval.py --name watchtower --agent knox \
     --session-id wt-daily-YYYY-MM-DD --model sonnet
   ```
   Write the printed eval id to `workflows/watchtower/state.yaml` top-level `eval_id` (not inside `accumulated-context`).

2. **Close the record** in `daily-step-06`, BEFORE setting `state.yaml status: complete`:
   ```bash
   python3 systems/eval-harness/close-eval-record.py --name watchtower --type workflow \
     --agent knox --status <success|partial|failure> --trigger boot \
     --started "<session-started from state.yaml>" \
     --steps "daily-step-01-gather,daily-step-02-dedupe,daily-step-03-score,daily-step-04-summarize,daily-step-04b-synthesize,daily-step-05-capture,daily-step-07-prune,daily-step-06-report"
   ```
   The order matters: `post-tool-use.py`'s cowork path creates a zero-step phantom when a state.yaml reaches `status: complete` and no completed record exists. Closing first makes GUARD 1 find the completed watchtower record and skip the phantom.

3. **Failure before daily-step-06:** the invoking step's failure path (boot step-04.5, or morning-briefing's Watchtower call) closes the record with `--status failure --abort-reason <cause>` so it never lingers in-progress. If no record was opened yet, skip the close.

A resumed run reuses the `eval_id` already in `state.yaml`; do not open a second record.

---

## Daily Run — Steps (Awareness)

| Step | File | Model | Description |
|------|------|-------|-------------|
| 01 | `steps/daily-step-01-gather.md` | haiku | Pull RSS feeds + web searches per topic; collect candidate items |
| 02 | `steps/daily-step-02-dedupe.md` | haiku | Drop items seen within dedupe window; update seen.jsonl |
| 03 | `steps/daily-step-03-score.md` | sonnet | Score items 0-100 against David's profile; drop below awareness_floor; update source-activity.json |
| 04 | `steps/daily-step-04-summarize.md` | sonnet | Write one-paragraph "what you should be aware of" per surviving item |
| 04b | `steps/daily-step-04b-synthesize.md` | sonnet | Generate through_line (synthesizing pattern) and consulting_read (editorial callout) from summarized items |
| 05 | `steps/daily-step-05-capture.md` | haiku | Write Obsidian daily note (with through-line); build/update dashboard artifact (with through-line banner + consulting-read callout) |
| 07 | `steps/daily-step-07-prune.md` | haiku | Dormancy check: retire sources silent >= 21d to dormant-sources.yaml |
| 06 | `steps/daily-step-06-report.md` | haiku | Summary of what was surfaced (includes retirements); hand content-worthy items to weekly queue |

**Step order note:** step-04b-synthesize runs between step-04-summarize and step-05-capture. Step-07-prune runs between step-05 and step-06. Step-06 reads retirements_today that step-07 writes.

## Weekly Run — Steps (Content + Sources)

| Step | File | Model | Description |
|------|------|-------|-------------|
| 01 | `steps/weekly-step-01-synthesize.md` | sonnet | Pull week's content-worthy items; synthesize themes |
| 02 | `steps/weekly-step-02-draft-angles.md` | sonnet | Draft HOOK + OUTLINE per content item; write to Obsidian + blog-ideas.md |
| 02b | `steps/weekly-step-02b-draft-tweets.md` | sonnet | Generate 10 ready-to-post tweets from week's signals; avoid overlap with blog angles; store in accumulated-context |
| 03 | `steps/weekly-step-03-suggest-sources.md` | sonnet | Propose up to max_per_week new sources; write to proposed-sources.md |
| 04 | `steps/weekly-step-04-weekly-note.md` | haiku | Write Obsidian weekly note summarizing themes, candidates, proposals, and tweets |
| 05 | `steps/weekly-step-05-report.md` | haiku | Surface content candidates ready + sources awaiting yes/no + tweets with Post to X links |
| 06 *(optional)* | `steps/weekly-step-06-publish-drafts.md` | sonnet | Runs an automated guardrail checkpoint on each draft before presenting them (leakage/attribution/tone review — see step file §3b); then presents approved drafts and sends selected posts to Slack `#content` (`C0B160MA3EK`) via master-slack skill; David selects or skips |
| 07 | `steps/weekly-step-07-adversarial-verify.md` | sonnet | Terminal adversarial verification - spawn Ralph with `workflows/watchtower-verification/workflow.md` (standing-intelligence accounting); record an `adversarial-verification` guardrail result |

**Step-06 is optional.** Knox presents a numbered draft list after step-05 completes and waits for David to select, send all, or skip. If skipped, the step is marked `status: skipped` and the weekly run closes normally. **Step-07 always runs** (whether step-06 was skipped or not) and is the run's terminal verification.

**Deterministic step guardrails:** Every step transition is machine-checked. The verifiers in `workflows/watchtower/verify/` run at each step's completion (dispatched by `.claude/hooks/step-complete.py`) and record a pass/retry/fail verdict with derived fields on the run's eval record. Manual review is not the gate.

**Adversarial verification:** weekly-step-07 spawns **Ralph** with `workflows/watchtower-verification/workflow.md` (the standing-intelligence accounting lens: drafts approved/posted vs source digests, no unpublished claims of publishing) and records the result as an `adversarial-verification` guardrail checkpoint.

---

## Source Registry

Active sources: `workflows/watchtower/sources.yaml`
Dormant sources (auto-retired, not polled): `workflows/watchtower/dormant-sources.yaml`
Proposed sources awaiting approval: `workflows/watchtower/proposed-sources.md`
Source activity ledger: `workflows/watchtower/source-activity.json`

Source approval gate: David explicitly approves or rejects each entry in `proposed-sources.md`. Approved entries are moved to `sources.yaml` by Rigby. Nothing auto-adds.

Dormancy rule: a source that surfaces no item clearing `awareness_floor` for 21 consecutive days is automatically moved from `sources.yaml` to `dormant-sources.yaml` by `daily-step-07-prune`. Retirements surface in the weekly report.

---

## Integration Contracts

| Downstream system | How Watchtower feeds it |
|-------------------|------------------------|
| `reference/blog-ideas.md` | Weekly step-02 appends candidate rows under `[watchtower]` marker |
| `Mind/` (Obsidian) | Weekly step-02 writes `_<slug>.md` draft files |
| `Watchtower/Daily/` (Obsidian) | Daily step-05 writes `YYYY-MM-DD.md` with `#watchtower` tag |
| `Watchtower/Weekly/` (Obsidian) | Weekly step-04 writes `YYYY-Www.md` |
| Boot briefing / morning briefing | Daily run is invoked by boot step-04.5 (or by morning-briefing before its step-01); top 5 items by score are returned as `watchtower_output.scored_items` and rendered inline as a Watchtower section with link to full dashboard; content candidate count noted |
| Slack `#content` (`C0B160MA3EK`) | Weekly step-06 (optional) sends selected draft posts via master-slack skill after David approves them |

Watchtower does NOT publish. It does NOT file vault notes outside its own folders. It feeds Harper's content pipeline and Knox's vault — it does not rebuild either.

Step-06 sends drafts to Slack `#content` as formatted messages for sharing — it does not post to LinkedIn, Twitter/X, or any other platform.
<!-- system:end -->

<!-- personal:start -->
<!-- personal:end -->
