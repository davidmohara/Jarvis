---
name: shutdown-cleanup
description: Session exit cleanup — purge temp artifacts, organize deliverables, verify naming, commit clean
agent: rigby
model: sonnet
---

<!-- system:start -->
# Shutdown Cleanup Workflow

**Goal:** Leave the workspace clean after every session. No temp artifacts committed, all deliverables properly named and placed, gitignore patterns up to date, and a clean commit.

**Agent:** Rigby — System Operator (owns shutdown-cleanup end-to-end; git via skills/git/SKILL.md)

**Architecture:** Automated 4-step workflow. Master runs this without controller interaction when exit is signaled. Report a summary of actions taken at the end.
<!-- system:end -->

<!-- personal:start -->
<!-- personal:end -->

---

<!-- system:start -->
## INITIALIZATION

### Trigger

This workflow runs automatically when the controller signals exit, log off, or end of session. It executes before the final commit.

### Artifact Categories

| Category | Examples | Action |
|----------|---------|--------|
| Intermediate build files | `.html` from PDF pipelines, temp scripts (`.js`, `.py`, `.sh`) | Delete |
| System artifacts | `.DS_Store`, `.fuse_hidden*`, `__pycache__`, `.tmp` | Delete |
| Deliverables | PDF, Word, PPTX, EPUB — generated for reading or distribution | Verify naming and location |
| Source files | Markdown files created or modified during the session | Verify naming convention |

### Output

- Clean workspace with no temp artifacts
- All deliverables properly named and located
- Updated `.gitignore` if new patterns discovered
- Summary of cleanup actions for the controller
<!-- system:end -->

<!-- personal:start -->
<!-- personal:end -->

---

<!-- system:start -->
## STATE CHECK

Read and follow `reference/state-check-protocol.md` before any execution. Workflow: `shutdown-cleanup`; agent: `rigby`.

## EXECUTION

**Dispatch model:** every step runs as a spawned sub-agent, no inline exception here at all.

1. Spawn one subagent (general-purpose, persona `agents/rigby.md`) with instructions to run STATE CHECK, then execute steps 01 through 04 in order, following each step's own frontmatter/state.yaml update protocol exactly as written.
2. Wait for it (block on the result) — the controller needs the cleanup summary this turn.
3. The subagent's final message must contain the complete summary produced in step-04 ("Shutdown cleanup complete: ..."), verbatim. Master relays that to the controller as its own next message.
4. If step-01's root-check finds a genuinely uncertain non-canonical entry, the subagent should pause and surface it in its response rather than guess; Master relays the question to the controller and, once answered, resumes the same subagent via SendMessage — this preserves `state.yaml`'s `current-step` and `accumulated-context`.

### Steps

| # | File | Executed by |
|---|------|-------------|
| 1 | `step-01-purge-artifacts.md` | spawned subagent |
| 2 | `step-02-organize-deliverables.md` | spawned subagent |
| 3 | `step-03-gitignore-check.md` | spawned subagent |
| 4 | `step-04-commit.md` | spawned subagent |
| 5 | `step-05-verify-cleanup.md` | spawned subagent |

Begin: `steps/step-01-purge-artifacts.md`
<!-- system:end -->

<!-- personal:start -->
<!-- personal:end -->
