---
status: not-started
model: sonnet
started-at: ~
completed-at: ~
---

<!-- system:start -->
# Step 03: Strategy Brief & Recommended Playbook

## MANDATORY EXECUTION RULES

1. You MUST produce a complete strategy brief following the fixed format. Do not skip sections.
2. You MUST analyze the account stage and generate a recommended playbook based on stage and history.
3. You MUST recommend specific next moves — not generic advice. "Build a relationship" is not a next move.
4. You MUST identify expansion opportunities where applicable.
5. You MUST include honest assessment of relationship gaps. Do not manufacture optimism.
6. You MUST write the completed strategy brief to the knowledge layer as type=`account-intelligence` with tags: account-name, relationship-health, competitive-landscape.
7. End with "Here's the play" — 3 specific next actions the executive can take in the next 30 days.

---

## EXECUTION PROTOCOL

**Agent:** Chase, spawned by the coordinator, never executed inline
**Input:** Account data from step 01, competitive intelligence from step 02
**Output:** Complete account strategy brief delivered to the executive

---

## CONTEXT BOUNDARIES

- Account stage classification drives the playbook. Classify before recommending.
- Playbook recommendations must be grounded in the actual account data — not generic best practices.
- Expansion opportunities are identified based on: known whitespace contacts, open opportunities, active engagements, and competitive displacement potential.
- "Specific next moves" means: who to call, what to propose, what meeting to schedule, what content to send.
- Data gaps are flagged explicitly. The executive needs to know what's unknown.

---

## YOUR TASK

### Sequence

Read `references/strategy-brief-structure.md` before writing the brief — it holds the exact section templates; each item below notes where its template moved.

1. **Analyze account stage:**
   Classify the account using these four stages:
   - `new` — first engagement, limited history, no closed revenue
   - `growing` — active engagements, open opportunities, expanding relationship
   - `mature` — established client, strong revenue, multiple contacts, at risk of commoditization
   - `at-risk` — declining engagement, no recent activity, competitive threat, or satisfaction issues
   Use tenure, revenue history, engagement activity, and relationship map data to classify.

2. **Section 1: Account Profile**
   [template moved — see `references/strategy-brief-structure.md`]

3. **Section 2: Relationship Map**
   [template moved — see `references/strategy-brief-structure.md`]

4. **Section 3: Open Opportunities**
   [template moved — see `references/strategy-brief-structure.md`]
   If no open opportunities: "No active pipeline on this account. Recommend a prospecting or re-engagement conversation to identify new opportunities."

5. **Section 4: Competitive Landscape**
   [template moved — see `references/strategy-brief-structure.md`]
   If no known competitors: "No competitive intel available. Consider probing in next conversation."

6. **Section 5: Recent Company Context**
   [template moved — see `references/strategy-brief-structure.md`]

7. **Section 6: Recommended Playbook**
   Based on the account stage, generate a recommended playbook:
   - `new`: focus on relationship building, discovery, and identifying the economic buyer
   - `growing`: focus on expansion, executive alignment, and advancing open opportunities
   - `mature`: focus on retention, executive sponsorship, and identifying new service lines
   - `at-risk`: focus on recovery — understand the issue, re-engage key contacts, address known concerns
   [template moved — see `references/strategy-brief-structure.md`]

8. **Identify expansion opportunities:**
   - Based on: whitespace contacts, account stage, active engagements, and competitive displacement potential
   - Each expansion opportunity should include: what it is, why now, and who to engage

9. **Write "Here's the Play" — 3 specific next actions for the next 30 days:**
   [template moved — see `references/strategy-brief-structure.md`]
   These must be specific: "Schedule a call with [name] to discuss [topic] before [date]" — not "reach out to the team."

10. **Write strategy brief to knowledge layer:**
    - Create a knowledge layer entry:
      - `type: account-intelligence`
      - `tags: [account-name, relationship-health, competitive-landscape]`
      - Content: the complete strategy brief
      - Context: account name, preparation date, account stage
    - Confirm write operation completed.

11. **Deliver the complete brief** to the executive.

---

## SUCCESS METRICS

- Account stage classified with supporting evidence
- Relationship map includes sponsors, champions, blockers, and whitespace
- Open opportunities summarized with at-risk flags
- Competitive landscape assessed honestly (even if unknown)
- Playbook recommendations specific to the account stage and history
- Expansion opportunities identified
- 3 specific next moves defined in "Here's the Play"

## FAILURE MODES

| Failure | Action |
|---------|--------|
| Insufficient data for full brief | Mark each data-sparse section clearly. Add "Data Gaps" section listing what's missing. Deliver what you have. |
| Account has no CRM history | Note: "New account — no prior history." Focus brief on competitive context and playbook for a new relationship. |
| No competitive data available | Mark competitive section as "Unknown." Recommend asking in next conversation. |
| Account stage is unclear | Default to `growing` if there is any active revenue. Default to `new` if there is no history. Document the reasoning. |

---

## WORKFLOW COMPLETE

Account strategy brief delivered. No further steps.

### Handoff Rules

| Condition | Route To | Action |
|-----------|----------|--------|
| Account needs client meeting prep for upcoming meeting | `client-meeting-prep` workflow | Chase runs client meeting prep with account strategy as foundation |
| Relationship recovery needed (at-risk account) | Shep (People & Leadership) | Flag the relationship risk — Shep advises on engagement play |
| Revenue rock threatened by account risk | Quinn (Strategy) | Escalate to Quinn for strategic review and reprioritization |
| Proposal or deck needed for expansion play | Harper (Communications) | Route content request with account context and playbook |
<!-- system:end -->


## WRITE WORKING MEMORY

Follow `reference/post-step-protocol.md` (Working Memory Write). Filename: `account-strategy-{YYYY-MM-DD}-{HHmmss}.md`; agent-source `chase`; compose the body from this step's output: key outputs, decisions, and any flags from the account strategy brief (3-5 bullets, under 200 words).

---
<!-- personal:start -->
<!-- personal:end -->
