---
status: not-started
started-at: ~
completed-at: ~
model: haiku
---

<!-- system:start -->
# Step 06: Dashboard, Close, Summary

## MANDATORY EXECUTION RULES

1. You MUST regenerate the dashboard before closing the eval record — the dashboard should reflect the grading and assertions completed in this run.
2. You MUST close the eval record via `close-eval-record.py` — do not leave it `in-progress`.
3. You MUST advance `state.yaml` to the terminal adversarial verification step (`current-step: step-07-adversarial-verify`) - do NOT set `status: complete` here; step-07 finalizes the state once its verdict is recorded.
4. You MUST deliver a summary to the controller — silence is not an option.

---

## EXECUTION PROTOCOL

**Agent:** Rigby, spawned by the coordinator, never executed inline
**Input:** All updated eval records + state.yaml accumulated context
**Output:** Updated dashboard HTML, closed eval record, final summary

---

## YOUR TASK

### 1. Regenerate the dashboard

Run the HTML generator:

```bash
python3 systems/eval-harness/generate-dashboard.py \
  --eval-dir systems/eval-harness/runs \
  --output systems/eval-harness/dashboard.html \
  --recent 100 \
  --period 30
```

Capture the exit code. If it fails, log the error — do not halt. Surface the path anyway, noting it may be stale.

Write the skill-run signal for `rigby-eval-dashboard`:

```json
{
  "skill": "rigby-eval-dashboard",
  "agent": "rigby",
  "trigger": "workflow:system-eval",
  "started": "<step start time>",
  "completed": "<ISO-8601 UTC now>",
  "status": "success",
  "tool_failures": 0,
  "error_ids": [],
  "records_visualized": <N from score output>,
  "output_path": "systems/eval-harness/dashboard.html"
}
```

Write to `systems/eval-harness/skill-runs/rigby-eval-dashboard-latest.json`.

### 2. Patch and sync the dashboard to the pinned Cowork artifact

#### 2a. Patch the Chart.js script tag

Run this sed replacement on the generated file before pushing to the artifact (this sed step is a safety net if an older script version generated the file):

the pinned sed command in `references/step-06-assets.md`

#### 2b. Push to the pinned Cowork artifact

**This step is MANDATORY. Do not skip it.**

First, load the tool schema (required before every call — it is always deferred):

```
ToolSearch with query "select:mcp__cowork__update_artifact"
```

Then call `mcp__cowork__update_artifact` with:

- **id:** `rigby-eval-dashboard`
- **html_path:** `systems/eval-harness/dashboard.html`
- **update_summary:** Brief description of what this run changed — include run date, records visualized, grades assigned, and avg score. Example: `"2026-07-08 run: 12 records, A:3 B:5 C:2 D:1 F:1, avg 0.74"`

**Verification:** After calling update_artifact, confirm the call succeeded. If the tool returns an error, retry once. If it fails again, log the failure in state.yaml under `dashboard_artifact_error` and continue — do not halt.

If the artifact update succeeded, write `dashboard_artifact_updated: true` to state.yaml. If it failed, write `dashboard_artifact_updated: false` with the error message.

### 3. Write working memory

Follow `reference/post-step-protocol.md` (Working Memory Write). Filename: `system-eval-YYYY-MM-DD-HHmmss.md`; agent-source: rigby. Compose the body from this step's output: records assessed, grades assigned, avg score, top pattern found, and any blocking failures.

After writing, verify the file exists and is >200 bytes via Bash (`wc -c {path}`). If verification fails, log `working-memory-status: failed` in state.yaml and continue — do not halt.

### 4. Close this workflow's eval record

Read `eval-record-id` from state.yaml (set by Step 1). Try the close script first:

```bash
python3 systems/eval-harness/close-eval-record.py \
  --name system-eval \
  --type workflow \
  --agent rigby \
  --status <success|partial|failure> \
  --trigger <manual|scheduled> \
  --started "<session-started from state.yaml>" \
  --steps "step-01-intake,step-02-assert,step-03-grade,step-04-score,step-05-analyze,step-06-dashboard"
```

**If the script creates a new record instead of closing the existing stub** (Cowork session_id mismatch — check the output; it will say "created:" instead of "closed:"), close the stub directly by writing to `systems/eval-harness/runs/{eval-record-id}.json` and updating these fields:
```json
{
  "completed": "<ISO-8601 UTC now>",
  "duration_seconds": <seconds from session-started to now>,
  "status": "<success|partial|failure>",
  "assessment": { "mechanical": { "completed": true, "all_steps_finished": true } }
}
```
Then delete the spurious new record the script created (it will be a fresh `eval-{timestamp}-{suffix}.json` written within the last 60 seconds).

Determine `--status`:
- `success` — all six steps completed with no blocking failures
- `partial` — one or more steps completed with non-blocking failures (e.g., score script errored but continued)
- `failure` — a step had to be skipped due to a blocking error

### 5. Advance state to the terminal verification step

```yaml
current-step: step-07-adversarial-verify
accumulated-context:
  step_timings:
    - step: step-06-dashboard
      started: <ISO-8601>
      completed: <ISO-8601>
```

Do NOT set `status: complete` here - step-07 (adversarial verification) finalizes the state.

### 6. Deliver summary

Output the following to the controller:

```
[Rigby]: System eval complete.

Records assessed: {records_total from state.yaml}
  Assertions run: {total_assertions_evaluated} across {total_records_asserted} records
  Grades assigned: {total_graded} ({grade_distribution: A:{N} B:{N} C:{N} D:{N} F:{N}})
  Avg composite score: {batch_average from scoring, or "N/A" if script failed}

Top finding: {top_recommendation from analysis}
Analysis report: {report_path}
Dashboard: systems/eval-harness/dashboard.html
```

If any steps had partial failures, append:
```
Partial failures:
  - {step}: {error description}
```

### 7. Weekly feedback prompt (Option C)

After delivering the summary, surface up to 3 eval records from the past 7 days that:
- Have `controller_feedback.rating == null`
- Have a composite score below 0.75 (most in need of signal)
- Are NOT orphaned abort stubs (must have at least 1 step)

Sort by score ascending (lowest first — most in need of feedback).

Output the prompt from `references/step-06-assets.md` (read it before surfacing).

**If this is a scheduled (headless) run:** omit this prompt entirely. The controller is not present. Write a note to state.yaml under `feedback_prompt: skipped (headless)` and stop.

**If this is a manual/interactive run:** wait for the controller's reply. For each rating received, write it back to the eval record immediately using the write-back snippet in `references/step-06-assets.md`.

Write `feedback_prompt: complete` to state.yaml after collecting ratings. If the controller replies "skip all" or gives no reply within the same turn, write `feedback_prompt: deferred`.

---

## SUCCESS METRICS

- Dashboard HTML regenerated
- Eval record closed (status: success, partial, or failure — not in-progress)
- state.yaml advanced to `step-07-adversarial-verify` (step-07 finalizes `status: complete`)
- Summary delivered

## FAILURE MODES

| Failure | Action |
|---------|--------|
| `generate-dashboard.py` fails | Log error. Surface the stale dashboard path with a note. Continue to close and summary. |
| Artifact update fails | Log the error to state.yaml under `dashboard_artifact_error`. Continue — dashboard on disk is the source of truth; artifact sync is non-blocking. |
| `close-eval-record.py` fails | Manually write the final state to the eval record in `runs/{eval-record-id}.json`. Set `status` and `completed` fields directly. Log that the script failed. |
| state.yaml write fails | Report it in the summary. Do not silently accept an unclosed state. |
<!-- system:end -->
