---
status: not-started
started-at: ~
completed-at: ~
model: sonnet
---

<!-- personal:start -->
# Step 04: Build PDF-Format Prep Sheet

## MANDATORY EXECUTION RULES

1. You MUST reference the template at `reference/podcast-prep-pdf-template.md` for the exact format.
2. You MUST condense 10+ questions down to exactly 5 focused prompts + 1 wrap-up. Combine related questions. Phrase the way David would actually ask them.
3. You MUST include all 8 sections in order: header, intro script, season/episode, title, overview, prompting questions, remember bar, sportcoat line.
4. You MUST save to `meetings/podcast-prep/Episode {N}.md` (plain episode number, no zero-padding, no guest name).
5. Do NOT add extra sections. This is a single-page document — every word must earn its place.

---

## EXECUTION PROTOCOL

**Agent:** Harper, spawned by the coordinator, never executed inline
**Input:** Detailed prep sheet from step 03, PDF template from reference
**Output:** PDF-format markdown at `meetings/podcast-prep/Episode {N}.md`

---

## YOUR TASK

### Read the Template

Read `reference/podcast-prep-pdf-template.md` for the exact format specification. Follow it precisely.

### Build the Document

The output file must follow this exact structure:

**IMPORTANT:** The markdown must use specific HTML elements for correct PDF rendering with `reference/podcast-prep-pdf.css`. Do NOT use standard markdown alternatives — these exact tags are required.

```markdown
<div class="banner">THE IMPROVING EDGE <span class="pipe">|</span> {Guest Full Name}, {Guest Title}</div>

<h4>INTRO SCRIPT</h4>

Welcome to **The Improving Edge**. This is where we talk about how AI and technology actually show up in real organizations; what works, what doesn't, and what we're learning along the way. I'll be sharing conversations with people doing the work, turning innovation into outcomes.

<center>Season 1, Episode {N}</center>

### {Episode Title}

## Episode Overview

{2-3 sentences summarizing the episode's focus. First-person plural ("We'll discuss...", "We'll dig into..."). Cover key themes without being exhaustive.}

## Prompting Questions

**1. On {Topic}**

> *"{Question phrased naturally, the way David would ask it}"*

**2. On {Topic}**

> *"{Question}"*

**3. On {Topic}**

> *"{Question}"*

**4. On {Topic}**

> *"{Question}"*

**5. On {Topic}**

> *"{Question}"*

**6. Wrap-Up**

> *"What are a couple of takeaways you'd like the listeners to walk away with?"*

<div class="remember"><strong>REMEMBER:</strong> Keep it conversational (60% guest / 40% host) • Share personal stories • Have fun!</div>

Sportcoat: _______________________________
```

### Format Consistency Rules — Read First

**Do not reinvent the format.** This document has a locked structure. Reference `meetings/podcast-prep/Episode 2.md` as the canonical example before writing a single line. The layout, tag choices, section order, and visual style must match it. If something looks different from the example, fix it — do not decide a variation is acceptable.

**One page is a hard constraint.** If the content does not fit on one page at readable size, cut content — do not shrink the font, reduce margins, or split onto a second page. Shorten questions and overview paragraph first. Every word must earn its place.

**Readable font size.** The CSS controls sizing, but your content length determines whether it fits. Keep the overview to 2-3 sentences max. Keep questions to 1-2 sentences max. If you're writing more than that, you're writing too much.

---

### Critical Formatting Rules

These rules ensure the PDF renders correctly with the CSS stylesheet:

- **Header**: Use `<div class="banner">THE IMPROVING EDGE <span class="pipe">|</span> {Guest}, {Title}</div>` — renders as dark blue banner with orange pipe and orange bottom border (NOT `#` markdown heading)
- **Intro label**: Use `<h4>INTRO SCRIPT</h4>` — renders as small orange label (NOT `## INTRO SCRIPT`)
- **Season/Episode**: Use `<center>Season 1, Episode {N}</center>` — centers the text (NOT bold paragraph)
- **Episode title**: Use `###` — renders as large centered bold title (NOT `#`)
- **Section headings**: Use `##` — renders as orange headings with underline
- **Questions**: Use `**N. On {Topic}**` paragraph + `> *"question"*` blockquote — renders as bold label with indented italic question (NOT ordered list `1.`)
- **REMEMBER bar**: Use `<div class="remember">` HTML — renders as blue bar with gold top border (NOT bold markdown)
- **No `---` horizontal rules** — use CSS spacing instead; `hr` elements add unwanted lines
- **No `<hr>` between sections** — the headings provide visual separation

### Distillation Rules

The key skill here is **condensation**. The detailed prep sheet has 8-10+ questions. This document has exactly 5 + wrap-up. Here's how to distill:

1. **Group related questions.** If the detailed sheet has 3 questions about adoption barriers, combine them into one prompt that naturally leads the guest through the topic.

2. **Cut the obvious.** If a question would get answered naturally in the flow of conversation, cut it. Keep only the questions that need to be asked deliberately.

3. **Phrase for David.** Not "Could you elaborate on the challenges of..." — instead "What breaks when you try to do this at scale?" Direct, curious, slightly provocative. The questions should sound like David having a conversation, not reading a teleprompter.

4. **Order for flow.** Start broad (define the topic, set context), go deep in the middle (challenges, real examples, contrarian takes), end forward-looking (future, advice), then wrap up.

4a. **Add follow-up prompts sparingly.** For 2-3 questions, add a single follow-up line beneath the question in italics — either a mechanism prompt ("*→ How does that actually show up?*") or a devil's advocate ("*→ What would someone say who disagrees?*"). One follow-up per question max. Skip them if they push the document past one page.

5. **The wrap-up is always the same:** "What are a couple of takeaways you'd like the listeners to walk away with?"

6. **Topic labels are 2-4 words.** Not sentences. "On Adoption Barriers" not "On The Challenges Organizations Face When Adopting AI."

7. **With the table removed, you have more space for questions.** Consider 6-7 questions if they fit on one page, keeping in mind the overview and Remember bar still need room.

---

## FAILURE MODES

| Failure | Action |
|---------|--------|
| Fewer than 5 questions | Expand your question set. The table is gone — you have room for 6-7 questions now if they fit. |
| Questions sound too scripted | Rewrite them more casually. Read them aloud mentally — would David say this in a real conversation? |
| Document runs long (won't fit one page) | Shorten the overview. Tighten question phrasing. Cut any word that isn't pulling its weight. |
| Template format unclear | Reference the existing example at `meetings/podcast-prep/Episode 2.md` for a real output. |
| Format looks different from prior episodes | Stop. Re-read `Episode 2.md` and align. Do not submit a variation — the format is locked. |
| Font too small or content overflows one page | Cut content. Shorten the overview and questions. Do not adjust font size or margins. |

---


## NEXT STEP

Read fully and follow: `step-05-generate-pdf.md`
<!-- personal:end -->

<!-- system:start -->
## Pre-Publish Guardrail Checkpoint (Stage 5 Phase 4A)

Before handing off to step-05 (which renders and delivers the studio PDF), record a `pre-publish-review` guardrail checkpoint over the assembled sheet:

- **Single-page discipline**: the assembled content fits one page at readable size (no forced font shrink, no second page).
- **Identity check**: the guest name and episode number in the banner and season line match the episode inputs.
- **Template conformance**: the required HTML elements (`class="banner"`, `<h4>INTRO SCRIPT</h4>`, `class="remember"`) are present per the locked format.

```bash
python3 systems/eval-harness/guardrail-checkpoint.py podcast-prep pre-publish-review step-04-build-pdf-sheet <pass|flag|escalate> "<one-line reason>"
```

- **pass** / **flag**: proceed to step-05.
- **escalate**: HALT. Do not generate or deliver the PDF. Surface the issue to David before continuing.
<!-- system:end -->

<!-- system:start -->
## Output Persistence (MANDATORY)

The verifier for this step finds the PDF-format markdown on disk (it does not read a nested block), so the save path and content are the contract. Save the file to `meetings/podcast-prep/Episode {N}.md` (plain episode number, no zero-padding, no guest name) and record its path in `state.yaml` `accumulated-context.pdf_markdown`.

The saved file MUST contain the three exact HTML markers the stylesheet depends on and exactly six numbered questions (five prompts plus the wrap-up), matching the pattern `^\*\*\d+\.\s`:

- `class="banner"`
- `<h4>INTRO SCRIPT</h4>`
- `class="remember"`
- exactly 6 `**N. ...**` question markers

```yaml
# state.yaml -> accumulated-context
pdf_markdown: "meetings/podcast-prep/Episode {N}.md"
```
<!-- system:end -->
