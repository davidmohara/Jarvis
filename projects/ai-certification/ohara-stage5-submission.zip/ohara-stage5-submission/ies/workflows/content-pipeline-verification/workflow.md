---
name: content-pipeline-verification
description: Adversarial verification of a content-pipeline run. Ralph accounts for every item end to end, from discovered through approved to published, and flags any silent drop.
agent: ralph
model: sonnet
---

<!-- personal:start -->
# Content Pipeline Verification Workflow

**Goal:** Confirm that every item the content pipeline touched is accounted for end to end: discovered items reach `pending-drafts.json`, tracker entries match live Ghost state (publishing is external — David publishes directly in Ghost), and no item is silently dropped between stages.

**Agent:** Ralph, Verification Agent

**Architecture:** Single-step adversarial pass. Ralph receives the pipeline manifest (step outputs, `pending-drafts.json`, state.yaml) and returns a verdict table. The caller acts on the results; Ralph never fixes anything.

**Adversarial lens (content-pipeline):** End-to-end accounting. The producing agent (Harper) reports what it believes it discovered, drafted, resynced, and edited; Ralph re-derives each item's journey from the recorded state: the #content Slack pull, the shared `workflows/content-approval/pending-drafts.json`, and the live Ghost post records. Any item that enters one stage and does not appear in the next, with no recorded explanation, is a silent drop. This is the content-pipeline lens in `agents/adversarial-isolation.md`.
<!-- personal:end -->

---

<!-- personal:start -->
## INITIALIZATION

### Data Sources Required

| Source | What to Pull | Access Method |
|--------|-------------|---------------|
| Pipeline manifest | Step output paths + run-date | Passed from Harper as accumulated-context |
| Step outputs | `workflows/content-pipeline/steps/step-0{1,2}-*.md` frontmatter `outputs` | File system read |
| Pending drafts | `workflows/content-approval/pending-drafts.json` (shared state file) | File system read |
| Workflow state | `workflows/content-pipeline/state.yaml` | File system read |
| Ghost post state | `mcp__ghost-blog__get_post` per referenced post id | Ghost API read |
| Slack source | The #content pull for this run | Passed in the manifest, or re-read via `systems/slack-bot/read.py` |

### Paths

- `discover_step` = `workflows/content-pipeline/steps/step-01-discover.md`
- `approve_step` = `workflows/content-pipeline/steps/step-02-approve.md`
- `pending_drafts` = `workflows/content-approval/pending-drafts.json`
- `state` = `workflows/content-pipeline/state.yaml`
<!-- personal:end -->

---

<!-- personal:start -->
## STATE CHECK: Run Before Any Execution

> Read and follow `reference/state-check-protocol.md` before any execution. Workflow name: `content-pipeline-verification`; agent: Ralph.

## EXECUTION

Read fully and follow: `steps/step-01-verify.md` to begin the workflow.
<!-- personal:end -->
