---
status: complete
started-at: "2026-10-21T15:25:00Z"
completed-at: "2026-10-21T15:27:00Z"
model: sonnet
---

<!-- system:start -->
# Step 02: Gather Tasks & Delegations

## MANDATORY EXECUTION RULES

1. You MUST take task management data from `data/omnifocus-unified.json`, the file the `omnifocus-data` skill wrote in boot step-01.2. No substitutions, and no direct OmniFocus calls.
2. You MUST check the delegation tracker file. Do not skip it.
3. You MUST read quarterly objectives to contextualize priorities.
4. Do NOT reprocess or triage tasks — that is the inbox-processing workflow. Just report what exists.
5. Do NOT proceed to step 03 until task and delegation data is captured.

---

## EXECUTION PROTOCOL

**Agent:** Chief, spawned by the coordinator, never executed inline in the coordinator's session.
**Input:** Consolidated task data from `data/omnifocus-unified.json` (pulled by boot step-01.2), delegation tracker (markdown), quarterly objectives (markdown)
**Output:** Task and delegation data stored in working memory for step 04

---

## CONTEXT BOUNDARIES

- Task data comes from consolidated file (pulled once in boot step-01.2), not from OmniFocus API
- Delegation tracker is the single source for delegated items. Do not reconstruct from memory.
- Quarterly objectives provide priority context — read but do not update.

---

## YOUR TASK

### Sequence

1. **Read inbox from consolidated file** `data/omnifocus-unified.json`.
   - File contains all uncompleted, unassigned inbox tasks (pulled by boot step-01.2)
   - Capture: task name, note, creation date (age is a triage signal)
   - Count = `inbox_count`
   - Do NOT call OmniFocus API directly.

2. **Extract tasks due today** from `data/omnifocus-unified.json`.
   - Filter for `due_date == today`
   - Include project name for each task
   - This data was pulled once in boot step-01.2

3. **Extract overdue tasks** from `data/omnifocus-unified.json`.
   - Filter for `due_date < today`
   - These are higher urgency than due-today — surface them first in the briefing
   - Pulled once in boot step-01.2, no API call needed

4. **Extract flagged tasks** from `data/omnifocus-unified.json`.
   - Filter for `is_flagged == true`
   - These represent controller-designated priorities
   - Pulled once in boot step-01.2

5. **Read delegation tracker** at `{project-root}/delegations/tracker.md`.
   - Identify overdue delegations (due date < today)
   - Identify delegations due today
   - Identify delegations due this week
   - Note who owns each

6. **Read quarterly objectives** at `{project-root}/memory/personal/quarterly-objectives.md`.
   - Capture each rock name and current status (1 line each)
   - These anchor the "what matters" frame for the briefing

7. **Store results** in working memory:
   ```
   task_data:
     inbox_count: N
     inbox_items: [{name, note, created, age_days}, ...]
     due_today: [{task, project}, ...]
     overdue: [{task, project, due_date, days_late}, ...]
     flagged: [{task, project}, ...]
   delegation_data:
     overdue: [{task, owner, due_date, days_late}, ...]
     due_today: [{task, owner}, ...]
     due_this_week: [{task, owner, due_date}, ...]
   rocks:
     - name: ... status: ...
   ```

---

## SUCCESS METRICS

- Inbox items read from `data/omnifocus-unified.json` (tasks with no `project`) — count and item list captured
- Due-today and overdue tasks derived from the same file's `due_date` field, with project context
- Flagged tasks derived from the same file's `is_flagged` field
- Delegation tracker parsed — overdue items identified with days late
- Quarterly rocks loaded with current status

## FAILURE MODES

| Failure | Action |
|---------|--------|
| `data/omnifocus-unified.json` missing, or its `status` is `failed` | Report the source as degraded: "OmniFocus unavailable. Task data missing from briefing." Proceed with delegation and rocks data only. If the file is missing entirely, re-run the `omnifocus-data` pull first. Do not treat a `failed` pull as a quiet task day. |
| Delegation tracker file missing | Report: "Delegation tracker not found." Proceed without delegation data. |
| Quarterly objectives file missing | Report: "Quarterly objectives not found." Proceed without rocks context. |

---


## NEXT STEP

Read fully and follow: `step-03-gather-context.md`
<!-- system:end -->

<!-- personal:start -->
<!-- personal:end -->
