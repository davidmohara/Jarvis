---
name: morning-briefing
description: Start-of-day briefing - calendar, priorities, delegations, meeting context, and what needs attention today
agent: chief
model: sonnet
---

<!-- system:start -->
# Morning Briefing Workflow

**Goal:** Give the controller complete situational awareness for the day ahead in under 2 minutes of reading.

**Agent:** Chief — Daily Operations & Execution

**Architecture:** Sequential 5-step workflow. Steps 01-03 gather data from different sources, step-04 synthesizes it into a single briefing, and step-05 runs an adversarial verification pass (Ralph) that cross-checks the delivered briefing against source data. No user interaction required until the briefing is delivered.

**Dispatch model:** This workflow runs as a **Chief** subagent spawned by the coordinator, never inline in the coordinator's session. Chief executes the steps below and spawns Knox for the Watchtower hand-off; the post-run commit routes to Rigby via `skills/git/SKILL.md`.
<!-- system:end -->

<!-- personal:start -->
<!-- personal:end -->

---

<!-- system:start -->
## INITIALIZATION

### Data Sources Required

| Source | What to Pull | Access Method |
|--------|-------------|---------------|
| Identity files | Current rocks, responsibilities, key people | Read identity layer files |
| Calendar | Today's meetings with attendees, times, locations | M365 MCP |
| Task management | Inbox count, due today, flagged items | `omnifocus-data` skill; read `data/omnifocus-unified.json` (written by boot step-01.2) |
| Delegation tracker | Overdue items, items due today | Read delegations/tracker.md |
| Knowledge layer | Recent meeting notes, previous daily review | Knowledge base API |

### Paths

- `identity_path` = `{project-root}/identity/`
- `delegation_tracker` = `{project-root}/delegations/tracker.md`
- `quarterly_objectives` = `{project-root}/memory/personal/quarterly-objectives.md`
<!-- system:end -->

<!-- personal:start -->
### Additional Data Sources

| Source | What to Pull | Access Method |
|--------|-------------|---------------|
| Clay | Upcoming reminders (next 7 days), upcoming birthdays, attendee relationship context | Clay MCP (mcp__clay__*) |
<!-- personal:end -->

---

<!-- system:start -->
## STATE CHECK

Read and follow `reference/state-check-protocol.md` before any execution. Workflow: `morning-briefing`; agent: `chief`.

## WATCHTOWER INVOCATION

Before step-01, delegate the Watchtower daily awareness pipeline to Knox so its output is fresh for the briefing. Chief does NOT execute the gather steps directly — this is a hand-off.

1. Spawn Knox with the following payload: "Run the Watchtower daily workflow: `workflows/watchtower/workflow.md` — read this file first, run the STATE CHECK, and execute the full daily run (daily-step-01 through daily-step-07-prune through daily-step-06) as written. Return `watchtower_output`."
2. Knox executes the gather→dedupe→score→summarize→synthesize→capture→prune chain, writes the Obsidian daily note and dashboard (with through-line banner and consulting-read callout), and returns the result of `daily-step-06-report.md` as `watchtower_output`.
3. Store `watchtower_output` in this workflow's `accumulated-context`. The top 5 items by score (from `watchtower_output.scored_items`) are surfaced in the morning briefing Watchtower section (step-04).

If Knox fails to spawn or the Watchtower run produces no items above the awareness floor, note it and proceed. Do NOT let a Watchtower failure block the morning briefing.

## DATA SOURCE UNREACHABLE — MANDATORY CHECK

This workflow and any sub-workflow/agent it invokes (Chase's lead-review, Knox's Watchtower/plaud-ingest, etc.) touch data sources that live on the host Mac outside this session's bash mount — e.g. `My Leads.xlsx` and the Plaud transcript staging folder. Before any step reports one of these as "not accessible," "unreachable," or "no Mac filesystem access":

1. Run `ToolSearch` for `mcp__Desktop_Commander__*` and `mcp__Control_your_Mac__osascript` — these are frequently deferred and absent from the initial tool list, which is not evidence they're unavailable.
2. Only after confirming those tools are genuinely unavailable (or the path doesn't exist even via them) is it valid to report the source as unreachable.
3. **OmniFocus is a special case, and it needs neither of those tools.** Read it with the `omnifocus-data` skill (`python3 skills/omnifocus-data/scripts/omnifocus_data.py pull`), which uses `osascript` directly and has no MCP or Desktop Commander dependency. Do NOT report OmniFocus unreachable because the MCP is not connected — that is a normal state, especially in unattended runs. Checking for Desktop Commander, not finding it, and stopping there is what degraded this source for five consecutive boots. Do not hand-write OmniFocus queries here either; the skill owns them.
4. See `systems/error-tracking/` entry `err-20260715T134820-X2GOL2` for the failure this guards against.

## EXECUTION

Read fully and follow: `steps/step-01-gather-calendar.md` to begin the workflow.

**Guardrail checkpoint:** After step-03 (gather context) and before step-04 (synthesize), `steps/step-03b-guardrail-checkpoint.md` runs an automated review of the gathered data. `pass`/`flag` continue normally; `escalate` requires step-04 to open the delivered briefing with an explicit data-quality warning rather than silently presenting bad data as clean.

**Adversarial verification:** After step-04 synthesizes the briefing, `steps/step-05-verify-briefing.md` spawns **Ralph** with `workflows/morning-briefing-verification/workflow.md` (the calendar/email/OmniFocus cross-check lens). Ralph re-derives every briefing claim from source data and returns a verdict table; the result is recorded as an `adversarial-verification` guardrail checkpoint. Findings are surfaced, never silently absorbed.

**Deterministic step guardrails:** Every step transition is machine-checked. The verifiers in `workflows/morning-briefing/verify/` run at each step's completion (dispatched by `.claude/hooks/step-complete.py`) and record a pass/retry/fail verdict with derived fields on the run's eval record. Manual review is not the gate.

<!-- system:end -->

<!-- personal:start -->
<!-- personal:end -->
