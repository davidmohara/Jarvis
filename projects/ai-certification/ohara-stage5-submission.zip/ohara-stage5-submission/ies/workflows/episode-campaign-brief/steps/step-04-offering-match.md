---
status: not-started
started-at: ~
completed-at: ~
model: sonnet
---

<!-- system:start -->
# Step 04: Offering Match + Brief Assembly

## MANDATORY EXECUTION RULES

1. Before executing, write `status: in-progress` and `started-at` to this
   file's frontmatter.
2. Load `accumulated-context.pain_points` from `state.yaml`.
3. You MUST query the live SharePoint sources named in
   `skills/offering-match/SKILL.md` — never a cached offerings list from a
   prior run, even a prior run in this same episode's history.
4. This is the final step. It also assembles and writes the Episode Campaign
   Brief document.

---

## EXECUTION PROTOCOL

**Agent:** Harper, spawned by the coordinator, never executed inline
**Input:** Pain points from `accumulated-context`
**Output:** Offering matches + the assembled Episode Campaign Brief markdown
document

---

## YOUR TASK

1. Read and execute `skills/offering-match/SKILL.md` in full, passing the
   pain points list. This queries live SharePoint sources — do not skip or
   shortcut this call.

2. Capture the returned `offering_matches` list (including any `no_match`
   entries — these belong in the brief too, as honest gaps), including the
   `buyer_persona`/`anti_buyer_persona` data attached to each matched
   offering. This persona data must actually render in the brief document
   below — it is not enough to have it in the skill's return value.

3. Assemble the Episode Campaign Brief markdown document with this structure:

   ```markdown
   # Episode Campaign Brief — {episode.title}

   **Episode:** {episode_number, if known} | **Date:** {date} | **Guest:** {guest, if any}
   **Source:** {source_url or obsidian_note_path}

   ## Pain Points

   ### {pain_point.id}: {pain_point.statement}
   > "{pain_point.quote}" — {speaker}
   {context}

   [repeat per pain point]

   ## Audience Profile

   **Industries:** {...}
   **Company size band:** {...} — {size_rationale}
   **Buyer roles:** {...}
   **Buying-trigger signals:** {...}

   ## Offering Matches

   ### {pain_point.id} → {offering_name}
   **Category:** {category} | **Duration:** {duration} | **Price:** {price}
   **Source:** [{source_doc}]({link})
   {fit_rationale}

   **Buyer / Anti-Buyer**
   - **Buyer persona:** {buyer_persona.name} ({buyer_persona.role}) — {buyer_persona.service_line}
     {buyer_persona.response}
     *Source: [{buyer_persona.source_doc}]({link})*
   - **Anti-buyer persona:** {anti_buyer_persona.name} ({anti_buyer_persona.role}){anti_buyer_persona.cross_referenced ? " — counters " + buyer_persona.name : " — generic blocker, not a confirmed cross-reference to " + buyer_persona.name}
     {anti_buyer_persona.response}
     *Source: [{anti_buyer_persona.source_doc}]({link})*

   [if persona_match_status is no_match, replace the Buyer / Anti-Buyer block with:]

   **Buyer / Anti-Buyer:** No buyer persona's Service line reasonably matched this offering's category. Not force-fit.

   [or, for offering gaps:]

   ### {pain_point.id} → No current offering match
   {reason}
   ```

   The Buyer / Anti-Buyer subsection only appears under offerings that actually
   matched (`match_status` not `no_match`) — there's no offering to attach a
   persona to for a gap. Never fabricate a persona pairing to fill this
   subsection; if `offering-match` returned `persona_match_status: no_match`
   for a given offering, render the plain no-match line above instead of
   omitting the subsection silently.

4. Save the brief to `content/podcast-campaigns/{episode-slug}-campaign-brief.md`
   (create the directory if it doesn't exist).

5. Record these outputs to `state.yaml` `accumulated-context`:
   ```yaml
   # state.yaml -> accumulated-context
   offering_matches_count: <int>
   unmatched_pain_points: [pp-0X, ...]
   brief_path: "content/podcast-campaigns/{episode-slug}-campaign-brief.md"
   ```

6. Update `state.yaml`:
   - `accumulated-context.offering_matches`: the full match list
   - `accumulated-context.brief_path`: the saved brief path
   - `status: complete`

7. Mark this file's frontmatter `status: complete` and `completed-at`.

8. Present the brief to the controller and note explicitly: "This brief can
   feed `audience-target-outreach` directly — want me to start account/contact
   targeting from this audience profile?"

---

## SUCCESS METRICS

- SharePoint sources were queried live this run (not answered from memory)
- Every offering match cites a real source document with duration/price
- Every matched offering's Buyer / Anti-Buyer subsection actually appears in
  the rendered brief document, not just in the skill's internal return value
- Persona selection never force-fits an unrelated persona — `no_match` on
  persona fit is rendered plainly when that's what the skill returned
- Unmatched pain points are stated plainly, not hidden or force-fit
- Brief document saved and presented

## FAILURE MODES

| Failure | Action |
|---------|--------|
| SharePoint unreachable | Do not fabricate offering matches. Save the brief with pain points + audience profile only, and flag: "Offering matching could not run — SharePoint sources unreachable. Retry offering-match once connectivity is restored." Set workflow `status` to `aborted` if the controller wants a complete brief before proceeding, or `complete` with the gap noted if a partial brief is acceptable. |

## NEXT STEP

This is the final step of `episode-campaign-brief`. If the controller wants to
continue into outreach, hand off to `workflows/audience-target-outreach/workflow.md`
using this run's `audience_profile` as input.
<!-- system:end -->

<!-- personal:start -->
<!-- personal:end -->
