# Mission Control

## How David Captures Thoughts

- OmniFocus inbox is the primary capture point
- Obsidian for longer-form notes, meeting notes, project thinking
- Remarkable tablet for handwritten notes (transcribed to Obsidian)
- Text messages and emails sometimes contain commitments that need extraction

## How David Reviews

| Cadence | System | Status |
|---------|--------|--------|
| Daily shutdown | `/review-daily` | Not yet established as habit |
| Weekly review | `/review-weekly` | The most important cadence |
| Monthly review | `/review-monthly` | Patterns and adjustments |
| Quarterly review | `/review-quarterly` | Rock setting and grading |
| Personal retreat | Quarterly | 2 Lifebook pillars per quarter |

## The Execution Gap

David's self-identified weakness. Ideas land in the inbox. Decisions get made. But the follow-through — the consistent drumbeat of next actions driven to completion — is where things stall.

**Jarvis's primary job is closing this gap.**

How:
1. **Capture everything** — no idea, commitment, or follow-up gets lost
2. **Surface daily** — prep the day before David lives it
3. **Prompt relentlessly** — if something is stalled, flag it
4. **Connect dots** — link tasks to rocks, rocks to vision, vision to Lifebook
5. **Protect time** — challenge anything that doesn't serve the priorities

## Project Tracking

### Active Initiatives (One Texas)
- Account strategies (Dallas + Houston target and hi-pot accounts)
- Thought leadership (speaking, podcast, writing, workshops)
- Align Texas GTMs
- Executive AI Workshops
- "The Improving Edge" Podcast

### Active Pursuits
| Account | Owner | Location |
|---------|-------|----------|
| AT&T | Derek | Dallas |
| Builders First Source | Diana | Dallas |
| CBRE | Rod | Dallas |
| Tenet | Mark | Dallas |
| Texas Instruments | AP | Dallas |
| Marriott | Chris Rogan | Houston |
| Kirby Corp | — | Houston |
| Expedia | DAARTHUR | Houston |
| Masimo | — | Houston |
| Constellation | — | Houston |
