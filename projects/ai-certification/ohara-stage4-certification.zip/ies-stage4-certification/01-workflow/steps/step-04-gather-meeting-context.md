---
status: complete
started-at: "2026-08-28T16:07:00Z"
completed-at: "2026-08-28T16:08:30Z"
outputs:
  meetings_found: "[redacted for certification submission — internal business/schedule detail, not relevant to guardrail/workflow mechanism]"
  meeting-context: "This is now ~11am CDT, mid-day: the morning's LSG Board Retreat tail, Dallas Virtual Coffee Chat, Sales & Recruiting Meeting, 4th Friday Executive Meeting, and Presidents Pipeline Roundtable are behind David. Remaining today: (1) SOW review for Dickason Honda of Paris (15:30-16:00 CDT w/ Derek Nwamadi, Anthony Marrical, client contact stevehall11565@gmail.com) — client SOW discussion, have the draft SOW ready; (2) Sync: David/Matt/Robin (12:30-13:00 CDT per Clay, w/ Ben Kennedy, Kevin Graham, Robin Graham, Matt Yasar) — recurring external sync, no new prep flagged, coming up shortly; (3) Executive AI Training Program Session 7/8 Wrap-Up (13:00-15:00 CDT per Clay / 18:00-20:00Z, in-person Dallas Conference Room Trust, large attendee list incl. Curtis Hite, Jorge Pliego, Susan Fojtasek, Ric DeAnda) — final session, may warrant a close-out note. 'Meet Susie' at 4-5pm CDT (NorthPark Center) still has no attendee record — personal, flagging for awareness only. Flag carried from first run: heavy day with retreat tail plus 6 internal/client meetings."
  clay-reminders: "available this run — 0 reminders returned (live pull succeeded, unlike first run's OAuth failure)"
  clay-birthdays: "available this run — no birthday-specific entries surfaced via getUpcomingEvents; 0 to report for the next 7 days"
  context-status: "ready — sufficient calendar and meeting-prep data for briefing synthesis. Clay now available and cross-verified against calendar-unified.json; no data gaps this run."
---

<!-- system:start -->
# Step 04: Gather Meeting Context (Phase 3)

## MANDATORY EXECUTION RULES

1. You MUST run morning briefing step-03 before proceeding. Do not synthesize the briefing without meeting context.
2. You MUST check Clay for reminders and birthdays. This is not optional — it is a standing controller requirement.
3. Do NOT proceed to step-05 until both tasks are complete.

---

## EXECUTION PROTOCOL

**Agent:** Master
**Input:** Calendar data from step-02 (morning briefing steps 01-02), Clay MCP
**Output:** Meeting prep context and Clay reminders/birthdays added to accumulated-context

---

## CONTEXT BOUNDARIES

- Morning briefing step-03 covers meeting-specific context (attendee research, prep flags). Run it as written.
- Clay check covers the next 7 days only. Do not pull beyond that range.
- Do not surface Clay data to the controller yet — it will be incorporated into the briefing in step-05.

---

## YOUR TASK

1. **Run morning briefing step-03.**
   Read and follow `workflows/morning-briefing/steps/step-03-*.md` in full. This step gathers meeting prep context for flagged meetings identified in steps 01-02.

2. **Check Clay for the next 7 days:**
   - Pull upcoming reminders via Clay MCP
   - Pull upcoming birthdays via Clay MCP (filter: upcoming_birthday, next 7 days)
   - Capture: name, date, relationship context, any associated notes

3. **Record results in accumulated-context:**
   ```yaml
   accumulated-context:
     phase3:
       morning-briefing-step-03: completed | nothing-to-surface | failed — [reason]
       clay-reminders: [list or "none"]
       clay-birthdays: [list or "none"]
   ```

4. **Update step frontmatter:** Set `status: complete`, `completed-at` with current timestamp, and `outputs.meetings_found` with a summary (e.g. "N events with full context — morning briefing step-03 completed, Clay data pulled").

5. **Update state.yaml:** Set `current-step: step-05-synthesize-briefing.md`.

---

## SUCCESS METRICS

- Morning briefing step-03 executed as written
- Clay reminders pulled (or absence confirmed)
- Clay birthdays pulled (or absence confirmed)
- All findings recorded in accumulated-context

## FAILURE MODES

| Failure | Action |
|---------|--------|
| Morning briefing step-03 file missing | Note the failure. Proceed without meeting-specific prep context. Surface in briefing: "Meeting prep context unavailable." |
| Clay MCP unavailable | Record: "Clay unavailable." Note in briefing that reminders and birthdays could not be checked. |
| Clay returns no results | Record: "Clay: nothing to surface." This is a valid outcome. |

---

## NEXT STEP

Read fully and follow: `step-05-synthesize-briefing.md`
<!-- system:end -->

<!-- personal:start -->
<!-- personal:end -->
